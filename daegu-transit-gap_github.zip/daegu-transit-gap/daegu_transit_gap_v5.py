# -*- coding: utf-8 -*-
"""
대구시 의료·일자리 대중교통 연결성 격차 분석 — V5 (최종)
=====================================================================
원본 CSV·ZIP 9종을 직접 읽어 전처리 → 결합 검증 → 노선망 연결성 → 공급(배차) 분석
→ 취약지역 우선순위 → AI(K-Means, RandomForest MDI, 최대커버리지) → 탄소 시나리오
→ 그림·표·검증표를 처음부터 끝까지 생성한다. 분석 결과 수치를 코드에 직접 입력한 곳은 없다.
정책 시나리오 가정값은 ASSUMPTIONS 에만 모아 두고, 출력물에 '가정'으로 표시한다.

실행:   이 파일과 같은 폴더에 data/ (원본 9종)를 두고 실행 버튼(또는 python daegu_transit_gap_v5.py)만 누르면
        outputs_v5/ 에 모든 표·그래프·검증표가 생성된다.  (폴더 지정: python daegu_transit_gap_v5.py <데이터폴더> <출력폴더>)
필요:   Python 3.9+, pandas, numpy, matplotlib, scikit-learn  (pip install pandas numpy matplotlib scikit-learn)
한글 폰트: Windows=맑은고딕 자동, Colab은 `!apt-get -qq install fonts-nanum` 후 런타임 재시작
"""
import os, re, io, sys, glob, json, zipfile, itertools, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import matplotlib.patheffects as pe
import matplotlib.transforms as mtrans
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, r2_score, mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, train_test_split
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

warnings.filterwarnings("ignore")
pd.set_option("display.width", 220); pd.set_option("display.max_columns", 40)

# 실행 버튼만 눌러도 동작: 이 파일과 같은 폴더의 data/ 를 읽고 outputs_v5/ 에 저장
try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:                     # 주피터·Colab 셀에 붙여넣어 실행한 경우
    BASE_DIR = os.getcwd()
_args = [a for a in sys.argv[1:] if not a.startswith("-")]   # 주피터 커널 인자(-f ...) 무시
_default_data = os.path.join(BASE_DIR, "data") if os.path.isdir(os.path.join(BASE_DIR, "data")) else BASE_DIR
DATA_DIR = os.path.abspath(_args[0] if len(_args) > 0 and os.path.isdir(_args[0]) else _default_data)
OUT_DIR = os.path.abspath(_args[1] if len(_args) > 1 else os.path.join(BASE_DIR, "outputs_v5"))
os.makedirs(OUT_DIR, exist_ok=True)

# =============================================================================
# 0. 설정값(분석 기준)과 가정값(정책 시나리오) — 분리 관리
# =============================================================================
CFG = dict(
    seed=42,
    walk_transfer_m=200,          # 정류소 간 도보 환승 허용 거리(기준값)
    walk_dest_m=500,              # 목적지 대표 정류소로부터 접근 반경(기준값)
    walk_subway_m=500,            # 정류소-도시철도역 도보 연결 거리
    sens_dest_m=[250, 500, 750],  # 민감도: 목적지 접근 반경
    sens_transfer_m=[100, 200, 300],  # 민감도: 환승 허용 반경
    long_headway_min=30,          # '장배차' 기준(공표 평균배차간격, 분)
    weekday_types=["평일", "공통"],   # 평일 분석에 사용할 시간표유형
    ride_months=12,               # 버스 승하차: 최근 n개월
    transfer_months=12,           # 환승수송: 최근 n개월
    rf_trees=500, rf_min_leaf=5,
    kmeans_k=range(2, 8),
    shuttle_hubs=6, shuttle_walk_m=400, shuttle_gap_m=1500,
    sens_shuttle_walk=[300, 400, 500], sens_shuttle_gap=[1000, 1500, 2000],
    drt_top_dongs=10, drt_k=10,
)
ASSUMPTIONS = dict(   # ※ 실측이 아닌 정책 시나리오 가정. 보고서에 반드시 '가정'으로 표기
    employment_rate=0.7,             # 20~39세 취업률
    complex_commute_share=0.10,      # 취업자 중 성서산단 통근 비율
    car_commute_share=0.6,           # 통근자 중 승용차 이용 비율
    shift_rates=[0.05, 0.10, 0.15],  # 승용차 → 셔틀 전환율
    road_detour=1.3,                 # 도로 우회계수(직선거리 × 1.3)
    working_days=250,                # 연간 운행일
    car_gco2_per_km=[110, 135, 160], # 승용차 주행 배출계수 범위(g/km) — 공식 단일값 미확인, 범위로 제시
    ebus_kwh_per_km=[1.0, 1.2, 1.4], # 전기버스 전비 범위 — 가정
    grid_tco2_per_mwh=0.4173,        # 2023년 국가 전력배출계수(기후에너지환경부 공표, 2025.12)
    shuttle_trips_per_line=4,        # 노선당 하루 왕복 횟수(공차회송 포함)
    shuttle_speed_kmh=25,            # 셔틀 평균속도(소요시간 추정용)
    walk_speed_elderly_mps=0.8, walk_speed_adult_mps=1.2,
)
HOSPITAL_STOP_KEYWORDS = {
    "경북대학교병원": ["경북대학교병원", "경북대학교치과병원"],
    "영남대학교병원": ["영대병원역"],
    "대구가톨릭대학교병원": ["대구가톨릭대학병원"],
    "계명대학교동산병원": ["계명대학교동산병원"],
    "칠곡경북대학교병원": ["칠곡경북대병원"],
}
COMPLEX_STOP_KEYWORDS = {
    "성서지방산업단지": ["성서산업단지역", "성서4차산업단지", "성서공단물류센터", "한국산업인력공단",
                         "한국산업은행성서지점", "성서협업단지", "한국환경공단"],
    "서대구일반산업단지": ["서대구공단네거리"],
    "대구제3일반산업단지": ["3공단지점", "공단역"],
    "북구검단일반산업단지": ["베어산업", "진흔건설기계공업", "혜성정공", "(주)성안", "성보교통"],
    "달성일반산업단지": ["달성산업단지", "관리공단", "공단하수처리장"],
    "달성2차일반산업단지": ["달성2차산업단지"],
    "대구국가산업단지": ["국가산단", "기업은행국가산단지점"],
}
DONG_ALIAS = {"다사읍서재출장소": "다사읍", "논공읍공단출장소": "논공읍", "구지읍": "구지면"}
SUBWAY_NAME_FALLBACK_EXCLUDE = {"대봉교", "부호", "하양", "정평", "임당", "영남대"}
PALETTE = dict(blue="#2a78d6", orange="#eb6834", aqua="#1baf7a", gray="#9a9893", ink="#0b0b0b",
               ink2="#52514e", grid="#e6e5e1", ord0="#86b6ef", ord1="#2a78d6", ord2="#104281")
EXPORT_DPI = 500

LOG, VALID, RESULT = [], [], {}
def log(msg=""):
    print(msg); LOG.append(str(msg))
def R(key, value):            # 보고서에 쓰일 수치를 한 곳에 기록 → 검증표·보고서가 이 값을 사용
    RESULT[key] = value; return value


# =============================================================================
# 1. 유틸리티
# =============================================================================
def setup_font():
    have = {f.name for f in fm.fontManager.ttflist}
    for c in ["Malgun Gothic", "AppleGothic", "NanumGothic", "NanumBarunGothic", "Noto Sans CJK KR", "Noto Sans CJK JP"]:
        if c in have:
            plt.rcParams["font.family"] = c; break
    else:
        print("[경고] 한글 폰트 없음 — Colab: !apt-get -qq install fonts-nanum 후 런타임 재시작")
    plt.rcParams.update({"axes.unicode_minus": False, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor": PALETTE["ink2"], "axes.labelcolor": PALETTE["ink2"],
                         "xtick.color": PALETTE["ink2"], "ytick.color": PALETTE["ink2"],
                         "axes.titleweight": "bold", "axes.titlesize": 11.5})


OUTPUT_NAME_PATTERNS = ("dong_", "stop_", "fig", "hotspot", "kmeans", "rf_", "sim_", "carbon", "validation",
                        "priority", "sensitivity", "v4_v5", "report_", "data_", "od_time", "extra")
def find_files(pattern):
    """원본 폴더에서만 검색. 출력 폴더와 분석 결과 파일명은 제외(결과를 원본으로 잘못 읽는 것 방지)."""
    hits = []
    for h in sorted(glob.glob(os.path.join(DATA_DIR, "**", pattern), recursive=True)):
        a = os.path.abspath(h)
        if a.startswith(OUT_DIR + os.sep) or not os.path.isfile(a):
            continue
        if os.path.basename(a).lower().startswith(OUTPUT_NAME_PATTERNS):
            continue
        hits.append(a)
    return hits


def find_one(pattern, label, required=True):
    h = find_files(pattern)
    if not h:
        if required:
            raise FileNotFoundError(f"[{label}] '{pattern}' 파일이 {DATA_DIR} 에 없습니다.")
        log(f"[{label}] 파일 없음 → 해당 분석 생략"); return None
    if len(h) > 1:
        log(f"[{label}] 후보 {len(h)}개 → 첫 파일 사용: {os.path.basename(h[0])}")
    return h[0]


def read_csv_auto(src, **kw):
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            if isinstance(src, (bytes, bytearray)):
                return pd.read_csv(io.BytesIO(src), encoding=enc, **kw), enc
            return pd.read_csv(src, encoding=enc, **kw), enc
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ValueError("인코딩 판별 실패")


def validate(name, df, key=None, enc="", period="", note=""):
    dup = int(df.duplicated(key).sum()) if key else np.nan
    VALID.append(dict(파일=name, 인코딩=enc, 행수=len(df), 열수=df.shape[1], 고유키=" + ".join(key) if key else "-",
                      키중복=dup, 결측셀비율_pct=round(float(df.isna().mean().mean() * 100), 3), 기간=period, 비고=note))


def haversine_m(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371000 * np.arcsin(np.sqrt(a))


def pairwise_m(la, oa, lb, ob):
    return haversine_m(np.asarray(la, float)[:, None], np.asarray(oa, float)[:, None],
                       np.asarray(lb, float)[None, :], np.asarray(ob, float)[None, :])


def save(fig, name, panels=None, dpi=EXPORT_DPI):
    p = os.path.join(OUT_DIR, name)
    fig.savefig(p, dpi=dpi, bbox_inches="tight", facecolor="white")
    if panels:
        fig.canvas.draw(); r = fig.canvas.get_renderer()
        for k, axs in panels.items():
            bb = mtrans.Bbox.union([a.get_tightbbox(r) for a in axs]).transformed(fig.dpi_scale_trans.inverted()).expanded(1.03, 1.04)
            fig.savefig(p.replace(".png", f"_{k}.png"), dpi=dpi, bbox_inches=bb, facecolor="white")
    plt.close(fig); log(f"  → 그림: {name}" + (f" (+패널 {', '.join(panels)})" if panels else ""))


def note(fig, text):
    fig.text(0.01, -0.02, text, fontsize=8, color=PALETTE["ink2"], ha="left", va="top")


def pct_rank(s, higher_is_worse=True):
    r = s.rank(pct=True, method="average")
    return r if higher_is_worse else 1 - r + (1 / len(s))


# =============================================================================
# 2. 원본 데이터 로드 + 검증
# =============================================================================
def load_population():
    f = find_one("*연령별인구*.csv", "인구")
    df, enc = read_csv_auto(f, thousands=",")
    ym = re.match(r"(\d{4}년\d{2}월)_계_", [c for c in df.columns if "_계_총인구수" in c][0]).group(1)
    validate(os.path.basename(f), df, ["행정구역"], enc, ym, "전국 행정구역")
    df = df[df["행정구역"].astype(str).str.contains("대구광역시")].copy()
    P = f"{ym}_계_"
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c].astype(str).str.replace(",", ""), errors="coerce")
    df["code"] = df["행정구역"].str.extract(r"\((\d{10})\)")[0]
    nm = df["행정구역"].str.replace(r"\s*\(\d+\)", "", regex=True).str.split()
    df["구군"], df["동"] = nm.str[1], nm.str[2]
    df["총인구"] = df[P + "총인구수"]
    df["청년2039"] = df[P + "20~29세"] + df[P + "30~39세"]
    df["생산2059"] = df[[P + f"{a}~{a+9}세" for a in (20, 30, 40, 50)]].sum(axis=1)
    old = [P + "60~69세", P + "70~79세", P + "80~89세", P + "90~99세", P + "100세 이상"]
    df["고령60"] = df[old].sum(axis=1)
    city = df[df["code"].str.endswith("00000000")].iloc[0]
    gu = df[df["code"].str.endswith("00000") & ~df["code"].str.endswith("00000000")][["구군", "총인구", "고령60", "청년2039"]].copy()
    dong = df[~df["code"].str.endswith("00000")].copy()
    dong["동"] = dong["동"].replace(DONG_ALIAS)
    dong = dong.groupby(["구군", "동"], as_index=False)[["총인구", "청년2039", "생산2059", "고령60"]].sum()
    dong = dong[dong["총인구"] > 0]
    R("pop_month", ym); R("pop_total", int(city["총인구"])); R("pop_60", int(city["고령60"]))
    R("pop_60_pct", round(city["고령60"] / city["총인구"] * 100, 2)); R("pop_2039", int(city["청년2039"]))
    R("n_dong_pop", len(dong))
    gu["고령60비율"] = (gu["고령60"] / gu["총인구"] * 100).round(2)
    for _, r in gu.iterrows():
        R(f"gu_old_pct|{r['구군']}", float(r["고령60비율"]))
    log(f"[인구] {ym} 대구 {RESULT['pop_total']:,}명, 60세+ {RESULT['pop_60']:,}명({RESULT['pop_60_pct']}%), 행정동 {len(dong)}")
    return dong, gu


def classify_route(r):
    if r.startswith("급행"): return "급행"
    if r.startswith("직행"): return "직행"
    if r.startswith("순환"): return "순환"
    if re.match(r"^\d", r): return "간선"
    return "지선"


def load_stops():
    f = find_one("*정류소*위치*.csv", "정류소 위치")
    bs, enc = read_csv_auto(f)
    validate(os.path.basename(f), bs, ["정류소명", "위도", "경도"], enc, "2026.09.02", "정류소ID 미제공")
    bs = bs.dropna(subset=["위도", "경도"]).reset_index(drop=True)
    bs["routes"] = bs["경유노선"].astype(str).str.split("+").apply(
        lambda xs: sorted({x.strip() for x in xs if x.strip() not in ("", "-", "nan")}))
    bs["has_express"] = bs["routes"].apply(lambda rs: any(classify_route(r) in ("급행", "직행") for r in rs))
    bs["only_feeder"] = bs["routes"].apply(lambda rs: len(rs) > 0 and all(classify_route(r) == "지선" for r in rs))
    bs["단일노선"] = bs["경유노선수"] <= 1
    R("n_stops", len(bs)); R("n_routes_loc", len({r for rs in bs["routes"] for r in rs}))
    g = bs.groupby("구군").agg(single=("단일노선", "mean"), avg=("경유노선수", "mean"))
    for k, r in g.iterrows():
        R(f"gu_single_pct|{k}", round(r["single"] * 100, 1)); R(f"gu_avg_routes|{k}", round(r["avg"], 2))
    log(f"[정류소] {len(bs):,}개, 노선 {RESULT['n_routes_loc']}개")
    return bs


def load_headway():
    f = find_one("*평균배차간격*.csv", "배차간격")
    hw, enc = read_csv_auto(f)
    hw.columns = [c.replace("﻿", "").strip() for c in hw.columns]
    validate(os.path.basename(f), hw, ["정류소ID", "노선", "진행방향", "시간표유형"], enc, "2025.11.14 기준", "공표 평균배차간격")
    hw["배차"] = pd.to_numeric(hw["평균배차간격"].astype(str).str.strip(), errors="coerce")
    hw["운행횟수"] = pd.to_numeric(hw["운행횟수"], errors="coerce")
    hw["정류소ID"] = pd.to_numeric(hw["정류소ID"], errors="coerce").astype("Int64")
    R("hw_rows", len(hw)); R("hw_ids", int(hw["정류소ID"].nunique())); R("hw_routes", int(hw["노선"].nunique()))
    R("hw_headway_missing_pct", round(hw["배차"].isna().mean() * 100, 2))
    wk = hw[hw["시간표유형"].isin(CFG["weekday_types"])].copy()
    R("hw_weekday_rows", len(wk))
    log(f"[배차] {len(hw):,}행, 정류소ID {RESULT['hw_ids']:,}, 노선 {RESULT['hw_routes']}, 배차 결측 {RESULT['hw_headway_missing_pct']}%"
        f"(운행 1회 노선 등) / 평일·공통 {len(wk):,}행 사용")
    return hw, wk


def load_route_info():
    f = find_one("*노선정보*.csv", "노선정보", required=False)
    if f is None: return None
    ri, enc = read_csv_auto(f)
    validate(os.path.basename(f), ri, ["노선ID"], enc, "2025.12.02", "기점·종점만 제공, 정류소 순서 없음")
    R("ri_rows", len(ri)); R("ri_route_numbers", int(ri["노선번호"].nunique()))
    R("ri_has_sequence", False)
    log(f"[노선정보] {len(ri)}개 노선 변형, 노선번호 {ri['노선번호'].nunique()}개 — 정류소 통과 순서 정보 없음(순서 생성 안 함)")
    log("  노선유형: " + ", ".join(f"{k} {v}" for k, v in ri["노선유형"].value_counts().items()))
    return ri


def load_subway(bs):
    f = find_one("*역별일별시간별*.csv", "도시철도 승하차")
    sw, enc = read_csv_auto(f)
    validate(os.path.basename(f), sw, ["월", "일", "역번호", "승하차"], enc, "2026.01~08", "")
    st = sw.drop_duplicates("역번호")[["역번호", "역명"]].sort_values("역번호").reset_index(drop=True)
    st["호선"] = st["역번호"].astype(str).str[0].astype(int)
    st["base"] = st["역명"].str.replace(r"\d+$", "", regex=True)
    lat, lon = [], []
    for b in st["base"]:
        key = b if b.endswith("역") else b + "역"
        m = bs[bs["정류소명"].str.startswith(key) | (bs["정류소명"].str.startswith(b + "(") & bs["정류소명"].str.contains("역"))]
        lat.append(m["위도"].mean() if len(m) else np.nan); lon.append(m["경도"].mean() if len(m) else np.nan)
    st["위도"], st["경도"] = lat, lon
    st["좌표출처"] = np.where(st["위도"].notna(), "정류소명 매칭", "")
    for _, g in st.groupby("호선"):
        for c in ("위도", "경도"):
            st.loc[g.index, c] = g[c].interpolate(limit_area="inside")
    st.loc[(st["좌표출처"] == "") & st["위도"].notna(), "좌표출처"] = "인접역 보간"
    for i in st.index[st["위도"].isna()]:
        b = st.at[i, "base"]
        if b in SUBWAY_NAME_FALLBACK_EXCLUDE: continue
        m = bs[bs["정류소명"].str.startswith(b)]
        if len(m):
            st.loc[i, ["위도", "경도"]] = [m["위도"].median(), m["경도"].median()]; st.at[i, "좌표출처"] = "정류소명 유사매칭"
    for _, g in st.groupby("호선"):
        miss = g["위도"].isna()
        for c in ("위도", "경도"):
            st.loc[g.index, c] = g[c].interpolate(limit_area="inside")
        st.loc[g.index[miss & st.loc[g.index, "위도"].notna()], "좌표출처"] = "인접역 보간"
    R("subway_n", len(st)); R("subway_coord", int(st["위도"].notna().sum()))
    for k in ["정류소명 매칭", "정류소명 유사매칭", "인접역 보간"]:
        R(f"subway_coord|{k}", int((st["좌표출처"] == k).sum()))
    R("subway_excluded", ", ".join(st.loc[st["위도"].isna(), "역명"]))
    sw["출근07_09"] = sw["07시-08시"] + sw["08시-09시"]
    alight = sw[sw["승하차"] == "하차"].groupby("역명")[["출근07_09", "일계"]].mean()
    for k in ["성서산업단지", "계명대", "경대병원"]:
        if k in alight.index: R(f"subway_am_alight|{k}", int(round(alight.at[k, "출근07_09"])))
    log(f"[도시철도] 역 {len(st)}개 중 좌표 {RESULT['subway_coord']}개, 제외: {RESULT['subway_excluded']}")
    return st, alight


def load_transfer(st):
    f = find_one("*환승수송*.csv", "버스-도시철도 환승", required=False)
    if f is None: return None
    t, enc = read_csv_auto(f)
    validate(os.path.basename(f), t, ["연도", "월", "유형"], enc, "", "월별·역별 환승 인원")
    t["ym"] = pd.to_datetime(t["연도"].astype(str) + "-" + t["월"].astype(str).str.zfill(2) + "-01")
    stations = [c for c in t.columns if c not in ("연도", "월", "유형", "ym")]
    last = sorted(t["ym"].unique())[-CFG["transfer_months"]:]
    tt = t[t["ym"].isin(last)].groupby("ym")[stations].sum().mean()   # 유형 합산 → 최근 n개월 월평균
    VALID[-1]["기간"] = f"{t['ym'].min():%Y.%m}~{t['ym'].max():%Y.%m} (분석: 최근 {len(last)}개월)"
    name_map = {"어린이세상": "어린이회관"}
    tt.index = [name_map.get(i, i) for i in tt.index]
    df = tt.rename("환승_월평균").reset_index().rename(columns={"index": "역명"})
    df = df.merge(st[["역명", "위도", "경도"]], on="역명", how="left")
    R("transfer_period", f"{pd.Timestamp(last[0]):%Y.%m}~{pd.Timestamp(last[-1]):%Y.%m}")
    R("transfer_station_match_pct", round(df["위도"].notna().mean() * 100, 1))
    top = df.sort_values("환승_월평균", ascending=False).head(5)
    R("transfer_top", ", ".join(f"{r.역명} {r.환승_월평균:,.0f}" for r in top.itertuples()))
    for k in ["성서산업단지", "계명대", "경대병원", "칠곡경대병원", "영대병원", "화원", "공단"]:
        v = df.loc[df["역명"] == k, "환승_월평균"]
        if len(v): R(f"transfer|{k}", int(round(v.iat[0])))
    log(f"[환승수송] {RESULT['transfer_period']} 월평균, 역 좌표 매칭 {RESULT['transfer_station_match_pct']}% / 상위: {RESULT['transfer_top']}")
    return df


def load_bus_ridership():
    frames = []
    for z in find_files("*정류소별*시간대별*.zip"):
        with zipfile.ZipFile(z) as zf:
            for info in zf.infolist():
                if info.filename.lower().endswith(".csv"):
                    d, enc = read_csv_auto(zf.read(info)); frames.append(d)
    if not frames:
        for f in find_files("*정류소별*시간대별*.csv"):
            d, enc = read_csv_auto(f); frames.append(d)
    d = pd.concat(frames, ignore_index=True)
    d = d.dropna(subset=["구분", "정류소ID"])
    d["ym"] = pd.to_datetime(d["년월"], errors="coerce").dt.to_period("M")
    d["정류소ID"] = pd.to_numeric(d["정류소ID"], errors="coerce").astype("Int64")
    bad_date = d["ym"].isna().sum(); d = d.dropna(subset=["ym"])
    hrs = [c for c in d.columns if re.fullmatch(r"\d{2}시", str(c))]
    validate("정류소별 시간대별 승하차(ZIP, 월별 CSV 합본)", d, ["정류소ID", "ym", "구분"], "cp949/utf-8",
             f"{d['ym'].min()}~{d['ym'].max()}", f"월 파일 {len(frames)}개, 날짜오류 {bad_date}행")
    last = sorted(d["ym"].unique())[-CFG["ride_months"]:]
    d = d[d["ym"].isin(last) & (d["구분"] == "승차")]
    g = d.groupby(["정류소ID", "ym"])[hrs].sum().groupby("정류소ID").mean()
    g["승차_일평균"] = g[hrs].sum(axis=1)
    g["승차_07_09"] = g["07시"] + g["08시"]
    R("ride_period", f"{last[0]}~{last[-1]}"); R("ride_daily_total", int(round(g["승차_일평균"].sum())))
    R("ride_ids", len(g))
    log(f"[버스승차] {RESULT['ride_period']} 일평균 승차 {RESULT['ride_daily_total']:,}회, 정류소ID {len(g):,}개")
    return g[["승차_일평균", "승차_07_09"] + hrs]


def load_destinations_raw():
    fm_, fi = find_one("*의료기관*.csv", "의료기관"), find_one("*산업단지*.csv", "산업단지")
    med, e1 = read_csv_auto(fm_); ind, e2 = read_csv_auto(fi)
    validate(os.path.basename(fm_), med, ["의료기관명", "소 재 지(도로명)"], e1, "2026.01.01", "")
    validate(os.path.basename(fi), ind, ["단지명", "회사명", "공장대표주소(지번)"], e2, "2026.08.25", "")
    top = med[med["종별"] == "상급종합병원"]
    R("n_med", len(med)); R("n_tertiary", len(top)); R("tertiary_beds", int(top["병상수 합계"].sum()))
    cnt = ind["단지명"].value_counts()
    R("n_firms", len(ind)); R("top4_firms", int(cnt.head(4).sum())); R("top4_pct", round(cnt.head(4).sum() / len(ind) * 100, 1))
    R("seongseo_firms", int(cnt.get("성서지방산업단지", 0)))
    return med, ind


# =============================================================================
# 3. 결합: 위치정보(ID 없음) ↔ 배차·승차(ID 있음)
#    이름이 유일하면 이름으로, 같은 이름이 여러 개면 '경유노선 구성의 자카드 유사도'가 가장 높은 ID로 결합
# =============================================================================
def assign_stop_ids(bs, wk, ride):
    hw_routes = wk.groupby("정류소ID")["노선"].apply(set)
    hw_name = wk.groupby("정류소ID")["정류소"].first()
    name_ids = hw_name.reset_index().groupby("정류소")["정류소ID"].apply(list)
    ids, how, jac = [], [], []
    for _, r in bs.iterrows():
        cands = name_ids.get(r["정류소명"], [])
        rs = set(r["routes"])
        if len(cands) == 0:
            ids.append(pd.NA); how.append("미매칭"); jac.append(np.nan); continue
        sc = [len(rs & hw_routes[c]) / max(1, len(rs | hw_routes[c])) for c in cands]
        k = int(np.argmax(sc))
        ids.append(cands[k]); jac.append(sc[k])
        how.append("이름 유일" if len(cands) == 1 else "동명 → 노선구성 매칭")
    bs = bs.copy(); bs["정류소ID"] = pd.array(ids, dtype="Int64"); bs["ID결합"] = how; bs["노선유사도"] = jac
    # 하나의 ID가 여러 위치 정류소에 붙은 경우(동명 중복) → 유사도 높은 1곳만 유지
    dupmask = bs["정류소ID"].notna() & bs.duplicated("정류소ID", keep=False)
    keep = bs[dupmask].sort_values("노선유사도", ascending=False).drop_duplicates("정류소ID").index
    drop = bs.index[dupmask & ~bs.index.isin(keep)]
    bs.loc[drop, ["정류소ID"]] = pd.NA; bs.loc[drop, "ID결합"] = "ID 중복 → 해제"
    vc = bs["ID결합"].value_counts()
    for k, v in vc.items(): R(f"idjoin|{k}", int(v))
    R("idjoin_rate", round(bs["정류소ID"].notna().mean() * 100, 1))
    R("idjoin_low_similarity", int(((bs["노선유사도"] < 0.5) & bs["정류소ID"].notna()).sum()))
    R("ride_join_rate", round(bs["정류소ID"].isin(ride.index).mean() * 100, 1))
    log(f"[ID 결합] 위치정보 {len(bs):,}개 → 정류소ID 부여 {RESULT['idjoin_rate']}% ("
        + ", ".join(f"{k} {v:,}" for k, v in vc.items()) + f"), 노선유사도<0.5: {RESULT['idjoin_low_similarity']}건")
    log(f"[ID 결합] 버스 승차(ID) 결합률 {RESULT['ride_join_rate']}%")
    return bs


def stop_supply(bs, wk):
    g = wk.groupby("정류소ID").agg(평일운행횟수=("운행횟수", "sum"), 배차_최단=("배차", "min"),
                                  배차_중앙=("배차", "median"), 배차노선수=("노선", "nunique"))
    dirs = wk.groupby("정류소ID").apply(lambda x: set(zip(x["노선"], x["진행방향"])))
    bs = bs.merge(g, left_on="정류소ID", right_index=True, how="left")
    bs["노선방향"] = bs["정류소ID"].map(dirs)
    bs["장배차"] = np.where(bs["배차_최단"].notna(), (bs["배차_최단"] >= CFG["long_headway_min"]).astype(float), np.nan)  # 분모=배차 결합 정류소
    R("supply_missing_pct", round(bs["평일운행횟수"].isna().mean() * 100, 1))
    R("headway_missing_pct_stop", round(bs["배차_최단"].isna().mean() * 100, 1))
    gu = bs.groupby("구군").agg(배차중앙=("배차_최단", "median"), 운행중앙=("평일운행횟수", "median"),
                              장배차=("장배차", "mean"), 전체=("정류소명", "size"), 유효=("배차_최단", "count"),
                              ID해제=("ID결합", lambda s: (s == "ID 중복 → 해제").sum()))
    gu["결합률"] = gu["유효"] / gu["전체"] * 100
    gu.to_csv(os.path.join(OUT_DIR, "headway_coverage_by_gu.csv"), encoding="utf-8-sig")
    for k, r in gu.iterrows():
        R(f"gu_hw_valid|{k}", int(r["유효"])); R(f"gu_hw_total|{k}", int(r["전체"])); R(f"gu_hw_rate|{k}", round(r["결합률"], 1))
        R(f"gu_hw_iddup|{k}", int(r["ID해제"]))
        R(f"gu_headway_med|{k}", float(r["배차중앙"])); R(f"gu_trips_med|{k}", float(r["운행중앙"]))
        R(f"gu_longhw_pct|{k}", round(r["장배차"] * 100, 1))
    gw = wk[wk["노선"].astype(str).str.startswith("군위")]
    if len(gw):
        R("gunwi_route_trips_min", int(gw.groupby("노선")["운행횟수"].median().min()))
        R("gunwi_route_trips_max", int(gw.groupby("노선")["운행횟수"].median().max()))
    s = bs.dropna(subset=["배차_최단"]).groupby("단일노선").agg(배차=("배차_최단", "median"), 운행=("평일운행횟수", "median"), n=("정류소명", "size"))
    R("single_headway_med", float(s.at[True, "배차"])); R("multi_headway_med", float(s.at[False, "배차"]))
    R("single_trips_med", float(s.at[True, "운행"])); R("multi_trips_med", float(s.at[False, "운행"]))
    log(f"[공급] 정류소별 배차 결측 {RESULT['headway_missing_pct_stop']}% / 단일노선 정류소 최단배차 중앙값 "
        f"{RESULT['single_headway_med']}분·운행 {RESULT['single_trips_med']}회 vs 다중노선 {RESULT['multi_headway_med']}분·{RESULT['multi_trips_med']}회")
    log(gu.round(1).to_string())
    return bs


# =============================================================================
# 4. 노선망 기반 '잠재' 환승 연결성 (BFS)
#    가정: 같은 노선에 정차하면 방향·순서와 무관하게 무환승 연결 가능 → '실제 최소 환승'이 아닌 '잠재 연결성'
# =============================================================================
def build_network(bs, st, transfer_m):
    bus_routes = sorted({r for rs in bs["routes"] for r in rs})
    st_ok = st.dropna(subset=["위도"]).reset_index(drop=True)
    routes = bus_routes + [f"도시철도{l}호선" for l in sorted(st_ok["호선"].unique())]
    ridx = {r: i for i, r in enumerate(routes)}; n = len(routes)
    A = np.zeros((n, n), bool)
    stop_r = [[ridx[r] for r in rs] for rs in bs["routes"]]
    D = pairwise_m(bs["위도"], bs["경도"], bs["위도"], bs["경도"])
    for i, j in zip(*np.where(D <= transfer_m)):
        for a in stop_r[i]: A[a, stop_r[j]] = True
    Dsb = pairwise_m(st_ok["위도"], st_ok["경도"], bs["위도"], bs["경도"])
    for k, row in st_ok.iterrows():
        li = ridx[f"도시철도{row['호선']}호선"]
        for j in np.where(Dsb[k] <= CFG["walk_subway_m"])[0]:
            A[li, stop_r[j]] = True; A[stop_r[j], li] = True
    Dss = pairwise_m(st_ok["위도"], st_ok["경도"], st_ok["위도"], st_ok["경도"])
    for a, b in zip(*np.where(Dss <= transfer_m)):
        A[ridx[f"도시철도{st_ok.at[a, '호선']}호선"], ridx[f"도시철도{st_ok.at[b, '호선']}호선"]] = True
    np.fill_diagonal(A, False)
    T = np.full((n, n), np.inf)
    for s in range(n):
        T[s, s] = 0; fr, d = [s], 0
        while fr:
            d += 1; nx = []
            for u in fr:
                for v in np.where(A[u] & np.isinf(T[s]))[0]:
                    T[s, v] = d; nx.append(v)
            fr = nx
    return routes, ridx, T, st_ok, int(A.sum() / 2)


def build_destinations(bs, st_ok, ridx, med, ind, dest_m):
    dests = []
    def near_routes(m):
        D = pairwise_m(m["위도"], m["경도"], bs["위도"], bs["경도"])
        js = np.unique(np.where(D <= dest_m)[1])
        rs = {ridx[r] for j in js for r in bs.at[j, "routes"]}
        Ds = pairwise_m(m["위도"], m["경도"], st_ok["위도"], st_ok["경도"])
        for k in np.unique(np.where(Ds <= CFG["walk_subway_m"])[1]):
            rs.add(ridx[f"도시철도{st_ok.at[k, '호선']}호선"])
        return rs, set(js.tolist())
    for _, h in med[med["종별"] == "상급종합병원"].iterrows():
        kws = HOSPITAL_STOP_KEYWORDS.get(h["의료기관명"])
        if not kws: log(f"  [경고] '{h['의료기관명']}' 키워드 없음 → 제외"); continue
        m = bs[bs["정류소명"].apply(lambda s: any(s.startswith(k) for k in kws))]
        rs, js = near_routes(m)
        dests.append(dict(type="의료", name=h["의료기관명"], weight=h["병상수 합계"], lat=m["위도"].mean(), lon=m["경도"].mean(), routes=rs, stops=js))
    cnt = ind["단지명"].value_counts()
    for cx, kws in COMPLEX_STOP_KEYWORDS.items():
        m = bs[bs["정류소명"].apply(lambda s: any(k in s for k in kws))]
        if len(m) == 0 or cx not in cnt: continue
        rs, js = near_routes(m)
        dests.append(dict(type="일자리", name=cx, weight=int(cnt[cx]), lat=m["위도"].mean(), lon=m["경도"].mean(), routes=rs, stops=js))
    return pd.DataFrame(dests)


def connectivity(bs, st, med, ind, transfer_m, dest_m, check_direction=False):
    routes, ridx, T, st_ok, n_edges = build_network(bs, st, transfer_m)
    dd = build_destinations(bs, st_ok, ridx, med, ind, dest_m)
    Dsub = pairwise_m(bs["위도"], bs["경도"], st_ok["위도"], st_ok["경도"])
    srs = []
    for i in range(len(bs)):
        s = {ridx[r] for r in bs.at[i, "routes"]}
        for k in np.where(Dsub[i] <= CFG["walk_subway_m"])[0]:
            s.add(ridx[f"도시철도{st_ok.at[k, '호선']}호선"])
        srs.append(np.array(sorted(s), dtype=int))
    TR = np.full((len(bs), len(dd)), np.inf)
    for j, d in dd.iterrows():
        tl = np.array(sorted(d["routes"]), dtype=int)
        sub = T[:, tl].min(axis=1)
        for i, s in enumerate(srs):
            if len(s): TR[i, j] = sub[s].min()
    out = bs[["구군", "동"]].copy()
    hos = (dd.type == "의료").values; job = (dd.type == "일자리").values
    Dh = pairwise_m(bs["위도"], bs["경도"], dd.loc[hos, "lat"], dd.loc[hos, "lon"]) / 1000
    near = Dh.argmin(axis=1); ar = np.arange(len(bs))
    out["의료_최근접병원"] = dd.loc[hos, "name"].values[near]
    out["의료_거리km"] = Dh.min(axis=1)
    out["의료_환승"] = TR[:, hos][ar, near]
    w = dd.loc[job, "weight"].values
    out["일자리_무환승기업비율"] = ((TR[:, job] == 0) @ w) / w.sum() * 100
    k = int(np.where(dd["name"].values == "성서지방산업단지")[0][0])
    out["성서_환승"] = TR[:, k]
    out["성서_거리km"] = haversine_m(bs["위도"], bs["경도"], dd.at[k, "lat"], dd.at[k, "lon"]) / 1000
    out["도시철도도보권"] = (Dsub <= CFG["walk_subway_m"]).any(axis=1)
    info = dict(n_routes=len(routes), n_edges=n_edges, dd=dd, st_ok=st_ok)
    if check_direction:
        info["direction"] = direction_check(bs, dd, out, ridx, srs, routes)
    return out, info


def direction_check(bs, dd, out, ridx, srs, routes):
    """무환승(0회) 판정 중 '같은 진행방향'으로 출발·목적지 정류소가 함께 운행되는지 배차자료로 확인.
       (정류소 통과 순서는 자료에 없으므로 순서는 검증하지 않음)"""
    rows = []
    for key, col, sel in [("의료", "의료_환승", lambda i: dd.index[(dd.type == "의료") & (dd.name == out.at[i, "의료_최근접병원"])][0]),
                          ("성서", "성서_환승", lambda i: dd.index[dd.name == "성서지방산업단지"][0])]:
        res = {"방향일치 확인": 0, "도시철도 포함(양방향)": 0, "방향 불일치(의심)": 0, "ID·배차자료 없음": 0}
        for i in np.where(out[col].values == 0)[0]:
            j = sel(i); d = dd.loc[j]
            common = set(srs[i].tolist()) & d["routes"]
            if any(routes[c].startswith("도시철도") for c in common):
                res["도시철도 포함(양방향)"] += 1; continue
            o_dir = bs.at[i, "노선방향"]
            if not isinstance(o_dir, set):
                res["ID·배차자료 없음"] += 1; continue
            dest_dirs = set().union(*[bs.at[s, "노선방향"] for s in d["stops"] if isinstance(bs.at[s, "노선방향"], set)] or [set()])
            names = {routes[c] for c in common}
            ok = any((r, dr) in dest_dirs for (r, dr) in o_dir if r in names)
            if not dest_dirs: res["ID·배차자료 없음"] += 1
            elif ok: res["방향일치 확인"] += 1
            else: res["방향 불일치(의심)"] += 1
        tot = sum(res.values())
        for k2, v in res.items():
            rows.append(dict(목적지=key, 판정=k2, 정류소수=v, 비율_pct=round(v / tot * 100, 1)))
    df = pd.DataFrame(rows)
    for r in df.itertuples():
        R(f"dircheck|{r.목적지}|{r.판정}", r.비율_pct)
    log("[BFS 검증] 무환승(0회) 판정 정류소의 진행방향 확인\n" + df.to_string(index=False))
    return df


# =============================================================================
# 5. 행정동 집계, 노출인구(잠재), 우선순위
# =============================================================================
def dong_table(bs, conn, pop, ride, transfer, st_ok):
    x = pd.concat([bs.reset_index(drop=True), conn.drop(columns=["구군", "동"]).reset_index(drop=True)], axis=1)
    x["승차_07_09"] = x["정류소ID"].map(ride["승차_07_09"]) if ride is not None else np.nan
    x["승차_일평균"] = x["정류소ID"].map(ride["승차_일평균"]) if ride is not None else np.nan
    f = lambda c, th: (c >= th).mean() * 100
    m = x.groupby(["구군", "동"]).agg(
        위도=("위도", "mean"), 경도=("경도", "mean"), 정류소수=("정류소명", "size"),
        평균경유노선수=("경유노선수", "mean"), 단일노선비율=("단일노선", lambda s: s.mean() * 100),
        급행정차비율=("has_express", lambda s: s.mean() * 100),
        배차_중앙=("배차_최단", "median"), 운행_중앙=("평일운행횟수", "median"),
        장배차비율=("장배차", lambda s: s.mean() * 100), 배차결측비율=("배차_최단", lambda s: s.isna().mean() * 100),
        의료_최근접병원=("의료_최근접병원", lambda s: s.mode().iat[0]), 의료_거리km=("의료_거리km", "mean"),
        의료_환승필요비율=("의료_환승", lambda s: f(s, 1)), 성서_거리km=("성서_거리km", "mean"),
        성서_환승필요비율=("성서_환승", lambda s: f(s, 1)), 일자리_무환승기업비율=("일자리_무환승기업비율", "mean"),
        승차_07_09=("승차_07_09", "sum"), 승차_일평균=("승차_일평균", "sum"),
        승차결합비율=("승차_일평균", lambda s: s.notna().mean() * 100),
    ).reset_index().merge(pop, on=["구군", "동"], how="left")
    m["고령60비율"] = m["고령60"] / m["총인구"] * 100
    m["의료_잠재노출인구"] = m["고령60"] * m["의료_환승필요비율"] / 100
    m["성서_잠재노출인구"] = m["청년2039"] * m["성서_환승필요비율"] / 100
    m["출근승차_천명당"] = m["승차_07_09"] / m["생산2059"] * 1000
    if transfer is not None:
        tr = transfer.dropna(subset=["위도"])
        D = pairwise_m(m["위도"], m["경도"], tr["위도"], tr["경도"])
        m["인근역_환승월평균"] = np.where(D <= 1500, tr["환승_월평균"].values[None, :], 0).sum(axis=1)
    return m, x


def exposure_summary(m, prefix=""):
    o = m["의료_잠재노출인구"].sum(); y = m["성서_잠재노출인구"].sum()
    return dict(old=o, old_pct=o / m["고령60"].sum() * 100, young=y, young_pct=y / m["청년2039"].sum() * 100)


PRIORITY_SETS = {
    "의료": {"고령60": True, "의료_환승필요비율": True, "평균경유노선수": False, "배차_중앙": True},
    "일자리": {"청년2039": True, "성서_환승필요비율": True, "평균경유노선수": False, "운행_중앙": False, "배차_중앙": True},
}
WEIGHT_SCENARIOS = {   # 지표 묶음별 가중치 (균등이 기준, 나머지는 민감도 확인용)
    "균등(기준)": dict(인구=1, 연결성=1, 노선=1, 공급=1, 수요=0),
    "연결성 2배": dict(인구=1, 연결성=2, 노선=1, 공급=1, 수요=0),
    "공급 2배": dict(인구=1, 연결성=1, 노선=1, 공급=2, 수요=0),
    "인구 제외": dict(인구=0, 연결성=1, 노선=1, 공급=1, 수요=0),
    "이용수요 포함": dict(인구=1, 연결성=1, 노선=1, 공급=1, 수요=1),
}
GROUP_OF = {"고령60": "인구", "청년2039": "인구", "의료_환승필요비율": "연결성", "성서_환승필요비율": "연결성",
            "평균경유노선수": "노선", "배차_중앙": "공급", "운행_중앙": "공급", "출근승차_천명당": "수요"}


def priority(m):
    res, sens = {}, []
    mm = m.dropna(subset=["총인구"]).copy()
    for target, inds in PRIORITY_SETS.items():
        inds = dict(inds); inds["출근승차_천명당"] = False   # 이용이 낮을수록 취약(민감도에서만 사용)
        ranks = pd.DataFrame({c: pct_rank(mm[c].fillna(mm[c].median()), worse) for c, worse in inds.items()})
        scores = {}
        for sc, w in WEIGHT_SCENARIOS.items():
            ww = pd.Series({c: w[GROUP_OF[c]] for c in inds})
            scores[sc] = (ranks * ww).sum(axis=1) / ww.sum()
        S = pd.DataFrame(scores); base = S["균등(기준)"]
        mm[f"{target}_우선점수"] = base
        mm[f"{target}_우선순위"] = base.rank(ascending=False, method="min").astype(int)
        top_base = set(base.nlargest(10).index)
        for sc in S.columns:
            sens.append(dict(대상=target, 가중치=sc, 기준과_순위상관=round(S[sc].corr(base, method="spearman"), 3),
                             상위10_일치=len(top_base & set(S[sc].nlargest(10).index))))
        res[target] = S
    sens = pd.DataFrame(sens)
    log("[우선순위 민감도]\n" + sens.to_string(index=False))
    for r in sens.itertuples():
        R(f"prio_sens|{r.대상}|{r.가중치}|top10", int(r.상위10_일치)); R(f"prio_sens|{r.대상}|{r.가중치}|rho", float(r.기준과_순위상관))
    return mm, sens


# =============================================================================
# 6. 그림
# =============================================================================
def fig_supply(bs):
    d = bs.dropna(subset=["배차_최단"])
    order = d.groupby("구군")["배차_최단"].median().sort_values().index
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8), gridspec_kw={"width_ratios": [1.35, 1]})
    data = [d.loc[d["구군"] == g, "배차_최단"].values for g in order]
    bp = ax[0].boxplot(data, vert=False, showfliers=False, patch_artist=True, widths=0.55)
    ax[0].set_yticks(range(1, len(order) + 1))
    nn = bs.groupby("구군").agg(t=("정류소명", "size"), v=("배차_최단", "count"))
    ax[0].set_yticklabels([f"{g}\n(n={nn.at[g, 'v']}/{nn.at[g, 't']})" for g in order], fontsize=8.5)
    for b in bp["boxes"]: b.set(facecolor="#cde2fb", edgecolor=PALETTE["blue"])
    for mdn in bp["medians"]: mdn.set(color=PALETTE["orange"], lw=2)
    for i, g in enumerate(order, 1):
        ax[0].text(np.median(data[i - 1]), i + 0.32, f"{np.median(data[i-1]):.0f}분", ha="center", fontsize=8.5, color=PALETTE["ink"])
    ax[0].axvline(CFG["long_headway_min"], color=PALETTE["gray"], ls="--", lw=1)
    ax[0].set_xlabel("정류소별 최단 공표 평균배차간격(분)"); ax[0].set_title("(a) 구·군별 공표 배차간격 분포", loc="left")
    s = d.groupby("단일노선").agg(배차=("배차_최단", "median"), 운행=("평일운행횟수", "median"))
    lab = ["다중노선 정류소", "단일노선 정류소"]
    ax[1].bar(lab, [s.at[False, "운행"], s.at[True, "운행"]], color=[PALETTE["blue"], PALETTE["orange"]], width=0.5)
    for i, (t, h) in enumerate([(s.at[False, "운행"], s.at[False, "배차"]), (s.at[True, "운행"], s.at[True, "배차"])]):
        ax[1].text(i, t, f"하루 {t:.0f}회\n(최단배차 {h:.0f}분)", ha="center", va="bottom", fontsize=9.5)
    ax[1].set_ylabel("평일 정류소 통과 운행횟수 합(중앙값)"); ax[1].set_ylim(0, max(s["운행"]) * 1.3)
    ax[1].set_title("(b) 단일노선 vs 다중노선 정류소 공급", loc="left")
    for a in ax: a.grid(axis="x" if a is ax[0] else "y", color=PALETTE["grid"]); a.set_axisbelow(True)
    note(fig, "자료: 대구광역시 정류소별 노선별 평균배차간격(2025.11.14, 평일·공통 시간표). n=배차 결합 정류소/전체 정류소. 정류소별 최단 공표배차의 구·군 중앙값이며 실제 대기시간이 아님.")
    fig.tight_layout(); save(fig, "fig1_supply_headway.png", {"a": [ax[0]], "b": [ax[1]]})


def fig_exposure(x, pop):
    xx = x.merge(pop, on=["구군", "동"], how="left")
    n = xx.groupby(["구군", "동"])["정류소명"].transform("size")
    xx["o_w"], xx["y_w"] = xx["고령60"] / n, xx["청년2039"] / n
    lab = ["무환승 연결", "1회 환승", "2회 이상·연결 없음"]; cols = [PALETTE["ord0"], PALETTE["ord1"], PALETTE["ord2"]]
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 5))
    for a, w, c, ttl in [(ax[0], "o_w", "의료_환승", "(a) 60세 이상 → 최근접 상급종합병원"), (ax[1], "y_w", "성서_환승", "(b) 20~39세 → 성서산업단지")]:
        g = pd.cut(xx[c].replace(np.inf, 99), [-1, 0, 1, 99], labels=lab)
        t = xx.assign(g=g).pivot_table(index="구군", columns="g", values=w, aggfunc="sum", observed=False).fillna(0)
        sh = (t.div(t.sum(axis=1), axis=0) * 100).sort_values(lab[0], ascending=False)
        left = np.zeros(len(sh))
        for l, col in zip(lab, cols):
            a.barh(sh.index, sh[l], left=left, color=col, height=0.62, label=l, edgecolor="white", linewidth=1.5)
            for yy, (l0, v) in enumerate(zip(left, sh[l])):
                if v >= 12: a.text(l0 + v / 2, yy, f"{v:.0f}", ha="center", va="center", fontsize=8, color="white" if l != lab[0] else PALETTE["ink"])
            left += sh[l].values
        a.set_xlim(0, 100); a.set_xlabel("대상인구 중 비중(%) — 잠재 노출 추정"); a.set_title(ttl, loc="left"); a.invert_yaxis()
        a.legend(loc="lower left", bbox_to_anchor=(0, 1.06), ncol=3, frameon=False, fontsize=8.5)
    note(fig, f"노선망 기반 잠재 환승 연결성(도보환승 {CFG['walk_transfer_m']}m·목적지 {CFG['walk_dest_m']}m). 인구는 동 내 정류소에 균등 배분한 추정치. 인구 {RESULT['pop_month']}.")
    fig.tight_layout(); save(fig, "fig2_transfer_exposure.png", {"a": [ax[0]], "b": [ax[1]]})


def _base_map(ax, bs, dd, dtype):
    core = bs[bs["위도"] <= 36.0]
    ax.scatter(core["경도"], core["위도"], s=1.2, color="#c9c8c2", zorder=1, linewidths=0)
    for gu, g in core.groupby("구군"):
        ax.text(g["경도"].median(), g["위도"].median(), gu, fontsize=9, color=PALETTE["ink2"], ha="center", zorder=6,
                fontweight="bold", path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])
    tg = dd[dd.type == dtype]
    ax.scatter(tg["lon"], tg["lat"], marker="P", s=150, color=PALETTE["blue"], edgecolor="white", lw=1.2, zorder=7)
    for _, r in tg.iterrows():
        nm = r["name"].replace("대학교", "대").replace("일반산업단지", "산단").replace("지방산업단지", "산단").replace("국가산업단지", "국가산단")
        ax.annotate(nm, (r["lon"], r["lat"]), xytext=(5, 5), textcoords="offset points", fontsize=7.5, color=PALETTE["blue"],
                    fontweight="bold", zorder=8, path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])
    ax.set_aspect(1 / np.cos(np.radians(35.87))); ax.set_xticks([]); ax.set_yticks([])
    for s_ in ax.spines.values(): s_.set_visible(False)


HEAT = matplotlib.colors.LinearSegmentedColormap.from_list("heat", ["#fdf0e6", "#f6a679", "#eb6834", "#a8371a", "#5c1a0b"])
def fig_heatmap(x, pop, dd):
    xx = x.merge(pop, on=["구군", "동"], how="left")
    n = xx.groupby(["구군", "동"])["정류소명"].transform("size")
    xx["o_w"], xx["y_w"] = xx["고령60"] / n, xx["청년2039"] / n
    core = xx[xx["위도"] <= 36.0]
    fig, ax = plt.subplots(1, 2, figsize=(14, 7.2)); cbs = []
    for a, w, c, dt, ttl in [(ax[0], "o_w", "의료_환승", "의료", "(a) 상급종합병원까지 환승이 필요한 60세 이상(잠재)"),
                             (ax[1], "y_w", "성서_환승", "일자리", "(b) 성서산단까지 환승이 필요한 20~39세(잠재)")]:
        hb = a.hexbin(core["경도"], core["위도"], C=np.where(core[c] >= 1, core[w].fillna(0), 0), reduce_C_function=np.sum,
                      gridsize=38, cmap=HEAT, mincnt=1, linewidths=0.3, edgecolors="white", zorder=2, alpha=0.92)
        _base_map(a, x, dd, dt)
        cb = fig.colorbar(hb, ax=a, shrink=0.6, pad=0.01); cb.set_label("격자(약 1km) 내 추정 인구(명)"); cbs.append(cb.ax)
        a.set_title(ttl, loc="left", fontsize=11)
    note(fig, "정류소 3,989개 기준(군위군 제외 표시). 인구는 동 인구를 정류소에 균등 배분한 추정치이며 실제 환승 이용객이 아님.")
    fig.tight_layout(); save(fig, "fig3_heatmap.png", {"a": [ax[0], cbs[0]], "b": [ax[1], cbs[1]]})


def fig_sensitivity(sens):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    d = sens[sens["변경"] == "목적지반경"]
    for col, c, lab in [("의료_노출비율", PALETTE["orange"], "60세+ → 상급병원"), ("성서_노출비율", PALETTE["blue"], "20~39세 → 성서산단")]:
        ax[0].plot(d["값"], d[col], "-o", color=c, lw=2, ms=7, label=lab)
        for xv, yv in zip(d["값"], d[col]): ax[0].text(xv, yv + 1.2, f"{yv:.1f}%", ha="center", fontsize=8.5, color=c)
    ax[0].set_ylim(d[["의료_노출비율", "성서_노출비율"]].min().min() - 4, d[["의료_노출비율", "성서_노출비율"]].max().max() + 5)
    ax[0].set_xticks(d["값"]); ax[0].set_xlabel("목적지 접근 반경(m)"); ax[0].set_ylabel("1회 이상 환승이 필요한 대상인구(%, 잠재)")
    ax[0].set_title("(a) 목적지 접근 반경 변화 (환승 허용 200m)", loc="left", fontsize=11); ax[0].legend(frameon=False, loc="upper right")
    d = sens[sens["변경"] == "환승반경"]
    for col, c, lab in [("의료_2회이상", PALETTE["orange"], "60세+ → 상급병원"), ("성서_2회이상", PALETTE["blue"], "20~39세 → 성서산단")]:
        ax[1].plot(d["값"], d[col], "-o", color=c, lw=2, ms=7, label=lab)
        for xv, yv in zip(d["값"], d[col]): ax[1].text(xv, yv, f" {yv:.2f}%", va="bottom", fontsize=8.5, color=c)
    ax[1].set_xticks(d["값"]); ax[1].set_xlabel("도보 환승 허용 반경(m)"); ax[1].set_ylabel("2회 이상 환승·연결 없음(%, 잠재)")
    ax[1].set_title("(b) 환승 허용 반경 변화 (목적지 500m)", loc="left", fontsize=11); ax[1].legend(frameon=False)
    for a in ax: a.grid(color=PALETTE["grid"]); a.set_axisbelow(True)
    note(fig, "같은 원본 자료로 기준값만 바꿔 재계산. '1회 이상 환승 필요' 비율은 환승 반경과 무관(무환승 판정은 목적지 반경에만 의존)하여 (b)는 2회 이상 비율을 표시.")
    fig.tight_layout(); save(fig, "fig4_sensitivity.png", {"a": [ax[0]], "b": [ax[1]]})


def fig_walk(walk):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
    for a, key, ttl in [(ax[0], "의료", "(a) 60세+ → 같은 상급병원 무환승 정류장까지"), (ax[1], "일자리", "(b) 20~39세 → 성서산단 무환승 정류장까지")]:
        s, med = walk[key]
        a.bar(s.index.astype(str), s.values, color=[PALETTE["ord0"], PALETTE["ord0"], PALETTE["ord1"], PALETTE["ord2"], PALETTE["ord2"]], width=0.6)
        for i, v in enumerate(s.values): a.text(i, v, f"{v:.0f}%", ha="center", va="bottom", fontsize=9)
        a.set_title(ttl + f" (중앙값 {med:.0f}m)", loc="left", fontsize=10.5); a.set_ylabel("환승필요 대상인구 중 비중(%)")
        a.grid(axis="y", color=PALETTE["grid"]); a.set_axisbelow(True)
    note(fig, "직선거리 기준. 환승이 필요한 정류소에서 같은 목적지로 무환승 연결되는 가장 가까운 정류소까지의 거리.")
    fig.tight_layout(); save(fig, "fig5_walk_alternative.png", {"a": [ax[0]], "b": [ax[1]]})


# =============================================================================
# 7. AI: RandomForest(MDI), K-Means, 최대커버리지, DRT
# =============================================================================
RF_FEATS = ["경유노선수", "평일운행횟수", "배차_최단", "급행정차", "지선만정차", "도시철도500m", "반경500m_정류소수",
            "도심거리_km", "동_주민_정류소당", "동_고령60비율", "의료_환승", "성서_환승"]


def run_rf(x, pop):
    d = x.merge(pop, on=["구군", "동"], how="left").copy()
    D = pairwise_m(d["위도"], d["경도"], d["위도"], d["경도"])
    d["반경500m_정류소수"] = (D <= 500).sum(axis=1) - 1
    c = d.loc[d["정류소명"].str.startswith("반월당"), ["위도", "경도"]].mean()
    d["도심거리_km"] = haversine_m(d["위도"], d["경도"], c["위도"], c["경도"]) / 1000
    d["동_주민_정류소당"] = d["총인구"] / d.groupby(["구군", "동"])["정류소명"].transform("size")
    d["동_고령60비율"] = d["고령60"] / d["총인구"] * 100
    d["급행정차"] = d["has_express"].astype(int); d["지선만정차"] = d["only_feeder"].astype(int)
    d["도시철도500m"] = d["도시철도도보권"].astype(int)
    d["의료_환승"] = d["의료_환승"].replace(np.inf, 4); d["성서_환승"] = d["성서_환승"].replace(np.inf, 4)
    d = d.dropna(subset=RF_FEATS + ["승차_07_09"]).reset_index(drop=True)
    X = d[RF_FEATS].astype(float).values; y = np.log1p(d["승차_07_09"].values)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=CFG["seed"])
    mk = lambda: RandomForestRegressor(n_estimators=CFG["rf_trees"], min_samples_leaf=CFG["rf_min_leaf"], random_state=CFG["seed"], n_jobs=-1)
    cv = []
    for tr, va in KFold(5, shuffle=True, random_state=CFG["seed"]).split(Xtr):
        mdl = mk().fit(Xtr[tr], ytr[tr]); p = mdl.predict(Xtr[va])
        cv.append((r2_score(ytr[va], p), mean_absolute_error(ytr[va], p)))
    cv = np.array(cv)
    rf = mk().fit(Xtr, ytr); pte = rf.predict(Xte)
    imp = pd.Series(rf.feature_importances_ / rf.feature_importances_.sum() * 100, index=RF_FEATS).sort_values()
    R("rf_n", len(d)); R("rf_n_train", len(Xtr)); R("rf_n_test", len(Xte))
    R("rf_cv_r2", round(cv[:, 0].mean(), 3)); R("rf_cv_r2_sd", round(cv[:, 0].std(), 3)); R("rf_cv_mae", round(cv[:, 1].mean(), 3))
    R("rf_test_r2", round(r2_score(yte, pte), 3)); R("rf_test_mae", round(mean_absolute_error(yte, pte), 3))
    for k, v in imp.sort_values(ascending=False).items(): R(f"rf_mdi|{k}", round(v, 1))
    R("rf_mdi_sum", round(imp.sum(), 1))
    cor = pd.DataFrame(X, columns=RF_FEATS).corr()
    hi = [(a, b, round(cor.at[a, b], 2)) for a, b in itertools.combinations(RF_FEATS, 2) if abs(cor.at[a, b]) >= 0.6]
    R("rf_high_corr_pairs", "; ".join(f"{a}-{b}({c})" for a, b, c in hi) or "없음")
    log(f"[RF] 정류소 {len(d):,}개(학습 {len(Xtr):,}/검증 {len(Xte):,}), 종속=log(1+07~09시 일평균 승차)")
    log(f"  5-Fold CV R² {RESULT['rf_cv_r2']}±{RESULT['rf_cv_r2_sd']}, MAE {RESULT['rf_cv_mae']} / 검증 R² {RESULT['rf_test_r2']}, MAE {RESULT['rf_test_mae']}")
    log("  MDI(%): " + ", ".join(f"{k} {v:.1f}" for k, v in imp.sort_values(ascending=False).items()))
    log(f"  |r|≥0.6 변수쌍: {RESULT['rf_high_corr_pairs']}")
    fig, ax = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={"width_ratios": [1.15, 1]})
    ax[0].barh(imp.index, imp.values, color=PALETTE["blue"], height=0.6)
    for i, v in enumerate(imp.values): ax[0].text(v + 0.3, i, f"{v:.1f}%", va="center", fontsize=8.5)
    ax[0].set_xlabel("MDI 변수 중요도(%, 합계 100)"); ax[0].set_xlim(0, imp.max() * 1.2)
    ax[0].set_title("(a) RandomForest 불순도 감소 기반 중요도(MDI)", loc="left", fontsize=11)
    ax[1].scatter(yte, pte, s=8, alpha=0.5, color=PALETTE["blue"], linewidths=0)
    lim = [0, max(yte.max(), pte.max())]; ax[1].plot(lim, lim, color=PALETTE["orange"], lw=1.2)
    ax[1].set_xlabel("관측 log(1+출근시간 승차)"); ax[1].set_ylabel("예측")
    ax[1].set_title(f"(b) 검증 데이터 예측 (R²={RESULT['rf_test_r2']}, MAE={RESULT['rf_test_mae']})", loc="left", fontsize=11)
    for a in ax: a.grid(color=PALETTE["grid"]); a.set_axisbelow(True)
    note(fig, f"대상: 승차자료(ID)와 결합된 정류소 {len(d):,}개, 버스 승차 {RESULT['ride_period']} 평균. 중요도는 예측 기여이며 인과효과가 아님.")
    fig.tight_layout(); save(fig, "fig6_rf_mdi.png", {"a": [ax[0]], "b": [ax[1]]})
    pd.DataFrame({"변수": imp.index, "MDI_pct": imp.values}).sort_values("MDI_pct", ascending=False).to_csv(
        os.path.join(OUT_DIR, "rf_feature_importance_mdi.csv"), index=False, encoding="utf-8-sig")
    return imp


KM_FEATS = ["의료_환승필요비율", "성서_환승필요비율", "의료_거리km", "단일노선비율", "평균경유노선수", "배차_중앙", "운행_중앙", "고령60비율"]


def run_kmeans(m):
    x = m.dropna(subset=["총인구"]).copy()
    X = x[KM_FEATS].copy(); X = X.fillna(X.median())
    Xs = StandardScaler().fit_transform(X.values)
    sil = {k: silhouette_score(Xs, KMeans(k, n_init=20, random_state=CFG["seed"]).fit_predict(Xs)) for k in CFG["kmeans_k"]}
    k = max(sil, key=sil.get)
    lab = KMeans(k, n_init=20, random_state=CFG["seed"]).fit_predict(Xs)
    x["유형"] = lab
    prof = x.groupby("유형").agg(동수=("동", "size"), 고령60=("고령60", "sum"), **{f: (f, "mean") for f in KM_FEATS})
    risk = prof["의료_환승필요비율"].rank() + prof["성서_환승필요비율"].rank() + prof["배차_중앙"].rank()
    names = {c: f"유형{i+1}" for i, c in enumerate(risk.sort_values(ascending=False).index)}
    x["유형"] = x["유형"].map(names); prof.index = prof.index.map(names); prof = prof.sort_index()
    prof["대표 동"] = x.groupby("유형").apply(lambda g: ", ".join(g.sort_values("총인구", ascending=False)["동"].head(5)))
    R("km_k", k); R("km_sil", round(sil[k], 3))
    for kk, v in sil.items(): R(f"km_sil|{kk}", round(v, 3))
    for i, r in prof.iterrows():
        R(f"km|{i}|n", int(r["동수"])); R(f"km|{i}|med", round(r["의료_환승필요비율"], 1)); R(f"km|{i}|job", round(r["성서_환승필요비율"], 1))
        R(f"km|{i}|hw", round(r["배차_중앙"], 1)); R(f"km|{i}|old", round(r["고령60비율"], 1)); R(f"km|{i}|dist", round(r["의료_거리km"], 1))
        R(f"km|{i}|single", round(r["단일노선비율"], 1)); R(f"km|{i}|members", r["대표 동"])
    log(f"[K-Means] 실루엣 " + ", ".join(f"k={a}:{b:.3f}" for a, b in sil.items()) + f" → k={k}")
    log(prof.round(1).to_string())
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.8), gridspec_kw={"width_ratios": [1, 2.4]})
    ax[0].plot(list(sil), list(sil.values()), "-o", color=PALETTE["blue"], lw=2)
    ax[0].scatter([k], [sil[k]], s=120, color=PALETTE["orange"], zorder=3)
    ax[0].set_xlabel("군집 수 k"); ax[0].set_ylabel("실루엣 계수"); ax[0].set_title("(a) 군집 수 선택", loc="left", fontsize=11)
    ax[0].grid(color=PALETTE["grid"])
    show = prof[["동수"] + KM_FEATS].astype(float)
    cols = ["동 수", "병원 환승필요%", "성서 환승필요%", "병원거리km", "단일노선%", "경유노선수", "배차 중앙(분)", "운행 중앙(회)", "60세+%"]
    z = (show - show.mean()) / show.std(ddof=0).replace(0, 1)
    ax[1].imshow(z.values, cmap="Blues", aspect="auto", vmin=-2, vmax=2)
    for i in range(z.shape[0]):
        for j in range(z.shape[1]):
            v = show.iat[i, j]
            ax[1].text(j, i, f"{v:,.0f}" if abs(v) >= 100 else f"{v:.1f}", ha="center", va="center", fontsize=8.5,
                       color="white" if z.iat[i, j] > 0.9 else PALETTE["ink"])
    ax[1].set_xticks(range(len(cols))); ax[1].set_xticklabels(cols, rotation=20, ha="right", fontsize=8.5)
    ax[1].set_yticks(range(len(show))); ax[1].set_yticklabels(show.index)
    ax[1].set_title("(b) 유형별 평균(색=유형 간 상대 수준)", loc="left", fontsize=11)
    for s_ in ax[1].spines.values(): s_.set_visible(False)
    note(fig, "변수 8개 표준화 후 K-Means(k=2~7 비교). 실루엣 계수가 0.5 미만이면 군집 경계가 뚜렷하지 않음을 의미.")
    fig.tight_layout(); save(fig, "fig7_kmeans.png", {"a": [ax[0]], "b": [ax[1]]})
    prof.to_csv(os.path.join(OUT_DIR, "kmeans_profile.csv"), encoding="utf-8-sig")
    return x[["구군", "동", "유형"]], prof


def max_coverage(x, w, walk_m, gap_m, n_hubs, need):
    D = pairwise_m(x["위도"], x["경도"], x["위도"], x["경도"])
    cover = D <= walk_m; covered = np.zeros(len(x), bool); hubs = []
    for _ in range(n_hubs):
        gain = cover @ np.where(covered, 0, w)
        if hubs: gain[(D[:, hubs] < gap_m).any(axis=1)] = -1
        gain[~need] = -1
        h = int(np.argmax(gain))
        if gain[h] <= 0: break
        hubs.append(h); covered |= cover[h]
    return hubs, covered


def run_shuttle(x, pop, dd, mprio):
    """선정 가중치 = 환승필요 20~39세(잠재) × V5 일자리 취약도 점수(0~1). 보고 수치는 가중 전 인구로 집계."""
    xx = x.merge(pop, on=["구군", "동"], how="left").merge(mprio[["구군", "동", "일자리_우선점수"]], on=["구군", "동"], how="left")
    xx = xx[xx["위도"] <= 36.0].reset_index(drop=True)
    n = xx.groupby(["구군", "동"])["정류소명"].transform("size"); xx["y_w"] = xx["청년2039"] / n
    need = (xx["성서_환승"] >= 1).values; w = np.where(need, xx["y_w"].fillna(0), 0.0)
    wsel = w * xx["일자리_우선점수"].fillna(0).values
    rows = []
    for wm in CFG["sens_shuttle_walk"]:
        for gm in CFG["sens_shuttle_gap"]:
            h, c = max_coverage(xx, wsel, wm, gm, CFG["shuttle_hubs"], need)
            rows.append(dict(도보반경m=wm, 거점간격m=gm, 잠재대상인구=round(w[c].sum()), 비율_pct=round(w[c].sum() / w.sum() * 100, 1)))
    sens = pd.DataFrame(rows)
    hubs, cov = max_coverage(xx, wsel, CFG["shuttle_walk_m"], CFG["shuttle_gap_m"], CFG["shuttle_hubs"], need)
    hv4, cv4 = max_coverage(xx, w, CFG["shuttle_walk_m"], CFG["shuttle_gap_m"], CFG["shuttle_hubs"], need)   # V4 방식(인구만)
    R("sh_v4method_cover", int(round(w[cv4].sum()))); R("sh_v4method_hubs", ", ".join(xx.loc[hv4, "동"]))
    H = xx.loc[hubs, ["정류소명", "구군", "동", "위도", "경도", "성서_거리km"]].reset_index(drop=True)
    H["잠재대상_청년"] = [round(w[(pairwise_m([xx.at[h, "위도"]], [xx.at[h, "경도"]], xx["위도"], xx["경도"])[0] <= CFG["shuttle_walk_m"])].sum()) for h in hubs]
    R("sh_need_total", int(round(w.sum()))); R("sh_cover", int(round(w[cov].sum()))); R("sh_cover_pct", round(w[cov].sum() / w.sum() * 100, 1))
    R("sh_hubs", ", ".join(f"{r.구군} {r.동} {r.정류소명}" for r in H.itertuples()))
    R("sh_sens_min", int(sens["잠재대상인구"].min())); R("sh_sens_max", int(sens["잠재대상인구"].max()))
    log(f"[셔틀] 기준(400m·1.5km) 거점 {len(hubs)}곳 → 잠재 대상 {RESULT['sh_cover']:,}명({RESULT['sh_cover_pct']}%) / 민감도 {RESULT['sh_sens_min']:,}~{RESULT['sh_sens_max']:,}명")
    log(H.round(1).to_string(index=False)); log(sens.to_string(index=False))
    # 운행순서(2개 노선 분할 포함) — 직선×우회계수
    sd = dd[dd.name == "성서지방산업단지"].iloc[0]; pts = H[["위도", "경도"]].values; dest = (sd["lat"], sd["lon"])
    dist = lambda a, b: haversine_m(a[0], a[1], b[0], b[1]) / 1000 * ASSUMPTIONS["road_detour"]
    def best(idx):
        b = (1e9, None)
        for p in itertools.permutations(idx):
            L = sum(dist(pts[p[i]], pts[p[i + 1]]) for i in range(len(p) - 1)) + dist(pts[p[-1]], dest)
            b = min(b, (L, p))
        return b
    b2 = (1e9, None)
    for r in range(1, len(H)):
        for g in itertools.combinations(range(len(H)), r):
            rest = tuple(i for i in range(len(H)) if i not in g)
            if g > rest: continue
            a, b = best(g), best(rest); b2 = min(b2, (a[0] + b[0], (a, b)))
    lines = list(b2[1])
    R("sh_line_km", round(b2[0], 1))
    for i, (L, p) in enumerate(lines, 1):
        R(f"sh_line{i}", " → ".join(H.loc[list(p), "정류소명"]) + " → 성서산단"); R(f"sh_line{i}_km", round(L, 1))
        R(f"sh_line{i}_min", int(round(L / ASSUMPTIONS["shuttle_speed_kmh"] * 60)))
    km_car = float(np.average(xx.loc[cov & need, "성서_거리km"] * ASSUMPTIONS["road_detour"] * 2, weights=w[cov & need] + 1e-9))
    R("sh_car_roundtrip_km", round(km_car, 1))
    sens.to_csv(os.path.join(OUT_DIR, "sensitivity_shuttle.csv"), index=False, encoding="utf-8-sig")
    H.to_csv(os.path.join(OUT_DIR, "sim_shuttle_hubs.csv"), index=False, encoding="utf-8-sig")
    return xx, hubs, cov, H, lines, km_car


def run_drt(x, pop, mprio):
    top = mprio.sort_values("의료_우선순위").head(CFG["drt_top_dongs"])[["구군", "동"]]
    xx = x.merge(pop, on=["구군", "동"], how="left").merge(top, on=["구군", "동"])
    n = xx.groupby(["구군", "동"])["정류소명"].transform("size"); xx["o_w"] = xx["고령60"] / n
    xx = xx[xx["의료_환승"] >= 1].reset_index(drop=True)
    w = xx["o_w"].fillna(0).values
    xy = np.c_[xx["위도"], xx["경도"] * np.cos(np.radians(35.87))]
    k = min(CFG["drt_k"], len(xx))
    km = KMeans(k, n_init=20, random_state=CFG["seed"]).fit(xy, sample_weight=w); xx["zone"] = km.labels_
    rows = []
    for z in range(k):
        g = xx[xx["zone"] == z]; lat, lon = km.cluster_centers_[z, 0], km.cluster_centers_[z, 1] / np.cos(np.radians(35.87))
        d = haversine_m(g["위도"], g["경도"], lat, lon)
        rows.append(dict(대표정류소=g.iloc[int(np.argmin(d))]["정류소명"], 구군=g["구군"].mode().iat[0], 동=g["동"].mode().iat[0],
                         위도=lat, 경도=lon, 포괄정류소=len(g), 잠재대상_60세=round(g["o_w"].sum()), 가중평균반경m=round(float(np.average(d, weights=g["o_w"] + 1e-9)))))
    Z = pd.DataFrame(rows).sort_values("잠재대상_60세", ascending=False).reset_index(drop=True); Z.insert(0, "거점", [f"D{i+1}" for i in range(len(Z))])
    R("drt_dongs", ", ".join(top["동"])); R("drt_stops", len(xx)); R("drt_pop", int(round(w.sum())))
    R("drt_hubs", ", ".join(f"{r.동} {r.대표정류소}" for r in Z.head(5).itertuples()))
    log(f"[DRT] V5 의료 우선순위 상위 {len(top)}개 동 → 환승필요 정류소 {len(xx)}곳, 잠재 대상 60세+ {RESULT['drt_pop']:,}명"); log(Z.to_string(index=False))
    Z.to_csv(os.path.join(OUT_DIR, "sim_drt_hubs.csv"), index=False, encoding="utf-8-sig")
    return xx, Z


def fig_policy(x, dd, sh, drt):
    xx, hubs, cov, H, lines, _ = sh; dx, Z = drt
    fig, ax = plt.subplots(1, 2, figsize=(14, 7.2))
    need = xx["성서_환승"] >= 1
    ax[0].scatter(xx.loc[need & ~cov, "경도"], xx.loc[need & ~cov, "위도"], s=6, color="#f6a679", zorder=2, label="환승 필요 정류소")
    ax[0].scatter(xx.loc[need & cov, "경도"], xx.loc[need & cov, "위도"], s=9, color=PALETTE["aqua"], zorder=3, label="거점 도보 400m 내(잠재 대상)")
    _base_map(ax[0], x, dd, "일자리")
    sd = dd[dd.name == "성서지방산업단지"].iloc[0]; pts = H[["위도", "경도"]].values
    for k, (L, p) in enumerate(lines):
        seq = [pts[i] for i in p] + [np.array([sd["lat"], sd["lon"]])]
        ax[0].plot([q[1] for q in seq], [q[0] for q in seq], "-", color=[PALETTE["orange"], PALETTE["blue"]][k], lw=2, zorder=8, label=f"노선 {k+1} ({L:.1f}km, 추정)")
    for i in range(len(H)):
        ax[0].scatter(pts[i][1], pts[i][0], s=90, color=PALETTE["ink"], edgecolor="white", lw=1.5, zorder=9)
        ax[0].annotate(f"S{i+1} {H.at[i, '정류소명']}", (pts[i][1], pts[i][0]), xytext=(6, -10), textcoords="offset points", fontsize=8, zorder=9,
                       path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])
    ax[0].legend(loc="lower right", frameon=False, fontsize=8, markerscale=2)
    ax[0].set_title(f"(a) 성서산단 직결셔틀 거점 {len(H)}곳·운행순서 (최대커버리지)", loc="left", fontsize=11)
    ax[1].scatter(dx["경도"], dx["위도"], s=7, c=dx["zone"], cmap="tab10", alpha=0.55, zorder=2)
    _base_map(ax[1], x, dd, "의료")
    for _, r in Z.iterrows():
        ax[1].scatter(r["경도"], r["위도"], s=60 + r["잠재대상_60세"] / max(1, Z["잠재대상_60세"].max()) * 400, color=PALETTE["orange"], edgecolor="white", lw=1.5, zorder=9, alpha=0.9)
        ax[1].annotate(f"{r['거점']} {r['동']}", (r["경도"], r["위도"]), xytext=(7, 4), textcoords="offset points", fontsize=8, zorder=9,
                       path_effects=[pe.withStroke(linewidth=2.5, foreground="white")])
    ax[1].set_title(f"(b) 의료 DRT 호출거점 {len(Z)}곳 (V5 의료 우선순위 상위 동, 가중 K-Means)", loc="left", fontsize=11)
    note(fig, "거점 반경 내 인구는 잠재 서비스 대상이며 실제 이용자·전환자가 아님. 노선 거리는 직선×1.3(가정).")
    fig.tight_layout(); save(fig, "fig8_policy.png", {"a": [ax[0]], "b": [ax[1]]})


def fig_rank_compare(cmp, target):
    d = cmp.head(12)
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    for _, r in d.iterrows():
        c = PALETTE["orange"] if r["V5"] < r["V4"] else (PALETTE["blue"] if r["V5"] > r["V4"] else PALETTE["gray"])
        ax.plot([0, 1], [r["V4"], r["V5"]], "-o", color=c, lw=1.8, ms=6)
        ax.text(-0.04, r["V4"], f"{r['동']} {int(r['V4'])}위", ha="right", va="center", fontsize=8.5)
        ax.text(1.04, r["V5"], f"{int(r['V5'])}위 {r['동']}", ha="left", va="center", fontsize=8.5)
    ax.set_xlim(-0.6, 1.6); ax.invert_yaxis(); ax.set_xticks([0, 1]); ax.set_xticklabels(["V4 (잠재 노출인구 순)", "V5 (복합지표 균등가중)"])
    ax.set_yticks([]); ax.spines["left"].set_visible(False)
    ax.set_title(f"{target} 취약지역 순위 변화 (V5 상위 12개 동)", loc="left", fontsize=11)
    note(fig, "주황=V5에서 상승, 파랑=하락. V5 지표: 대상인구·환승필요비율·경유노선수·배차(·운행횟수) 백분위 순위의 균등 평균.")
    save(fig, f"fig9_rank_{'medical' if target=='의료' else 'job'}.png")


# =============================================================================
# 8. 탄소 시나리오
# =============================================================================
def carbon(sh):
    A = ASSUMPTIONS; _, _, _, H, lines, km_car = sh
    served = RESULT["sh_cover"]
    commuters = served * A["employment_rate"] * A["complex_commute_share"] * A["car_commute_share"]
    bus_km = sum(L for L, _ in lines) * 2 * A["shuttle_trips_per_line"] * A["working_days"]
    rows = []
    for s in A["shift_rates"]:
        for ef in A["car_gco2_per_km"]:
            car = commuters * s * km_car * A["working_days"] * ef / 1e6
            for kwh in A["ebus_kwh_per_km"]:
                bus = bus_km * kwh * A["grid_tco2_per_mwh"] / 1000
                rows.append(dict(전환율=s, 승용차배출계수=ef, 전기버스전비=kwh, 전환자_명=round(commuters * s),
                                 회피배출_t=round(car, 1), 셔틀배출_t=round(bus, 1), 순감축_t=round(car - bus, 1)))
    df = pd.DataFrame(rows); df.to_csv(os.path.join(OUT_DIR, "carbon_scenarios.csv"), index=False, encoding="utf-8-sig")
    R("cb_commuters", int(round(commuters))); R("cb_bus_km", int(round(bus_km)))
    for s in A["shift_rates"]:
        g = df[df["전환율"] == s]
        R(f"cb|{int(s*100)}|avoid_min", float(g["회피배출_t"].min())); R(f"cb|{int(s*100)}|avoid_max", float(g["회피배출_t"].max()))
        R(f"cb|{int(s*100)}|net_min", float(g["순감축_t"].min())); R(f"cb|{int(s*100)}|net_max", float(g["순감축_t"].max()))
        R(f"cb|{int(s*100)}|n", int(round(commuters * s)))
    R("cb_bus_min", float(df["셔틀배출_t"].min())); R("cb_bus_max", float(df["셔틀배출_t"].max()))
    R("cb_per1000", round(1000 * km_car * A["working_days"] * A["car_gco2_per_km"][1] / 1e6, 1))
    log(f"[탄소·가정] 잠재 대상 {served:,} → 가정 적용 승용차 통근 {commuters:,.0f}명, 셔틀 연 {bus_km:,.0f}km, 왕복 {km_car:.1f}km")
    log(df.groupby("전환율")[["회피배출_t", "셔틀배출_t", "순감축_t"]].agg(["min", "max"]).to_string())
    fig, ax = plt.subplots(figsize=(8.5, 4.4))
    for i, s in enumerate(A["shift_rates"]):
        g = df[df["전환율"] == s]
        ax.plot([i, i], [g["순감축_t"].min(), g["순감축_t"].max()], color=PALETTE["blue"], lw=8, solid_capstyle="butt", alpha=0.6)
        mid = g[(g["승용차배출계수"] == A["car_gco2_per_km"][1]) & (g["전기버스전비"] == A["ebus_kwh_per_km"][1])]["순감축_t"].iat[0]
        ax.scatter([i], [mid], color=PALETTE["orange"], s=60, zorder=3)
        ax.text(i + 0.12, mid, f"중간값 {mid:.0f}t\n범위 {g['순감축_t'].min():.0f}~{g['순감축_t'].max():.0f}t", va="center", fontsize=8.5)
    ax.axhline(0, color=PALETTE["ink2"], lw=1)
    ax.set_xticks(range(len(A["shift_rates"]))); ax.set_xticklabels([f"전환율 {int(s*100)}%" for s in A["shift_rates"]])
    ax.set_ylabel("연간 순감축량(tCO2, 시나리오)"); ax.set_xlim(-0.5, len(A["shift_rates"]) - 0.2)
    ax.set_title("셔틀 도입 시 순감축량 시나리오 (회피배출 − 전기셔틀 배출)", loc="left", fontsize=11)
    ax.grid(axis="y", color=PALETTE["grid"]); ax.set_axisbelow(True)
    note(fig, f"가정: 승용차 {A['car_gco2_per_km']}g/km, 전비 {A['ebus_kwh_per_km']}kWh/km, 전력배출계수 {A['grid_tco2_per_mwh']}tCO2/MWh(2023), 운행 {A['working_days']}일.")
    save(fig, "fig10_carbon.png")
    return df


# =============================================================================
# 9. 보행 대안 분석
# =============================================================================
def walk_alt(x, pop):
    xx = x.merge(pop, on=["구군", "동"], how="left"); xx = xx[xx["위도"] <= 36.0].reset_index(drop=True)
    n = xx.groupby(["구군", "동"])["정류소명"].transform("size"); xx["o_w"], xx["y_w"] = xx["고령60"] / n, xx["청년2039"] / n
    D = pairwise_m(xx["위도"], xx["경도"], xx["위도"], xx["경도"])
    res = {}; bins = [0, 300, 500, 800, 1500, np.inf]; labels = ["300m 이내", "300~500m", "500~800m", "800m~1.5km", "1.5km 초과"]
    for key, tcol, wcol, near in [("의료", "의료_환승", "o_w", "의료_최근접병원"), ("일자리", "성서_환승", "y_w", None)]:
        need = (xx[tcol] >= 1).values; ok = (xx[tcol].values == 0)[None, :]
        if near:
            nc = np.asarray(xx[near].astype(str).tolist(), dtype=object); ok = ok & (nc[:, None] == nc[None, :])
        dist = np.where(ok, D, np.inf).min(axis=1)
        xx[f"{key}_무환승정류장까지m"] = np.where(need, dist, 0)
        g = pd.cut(pd.Series(dist[need]), bins, labels=labels, include_lowest=True)
        sh = pd.Series(xx[wcol].fillna(0).values[need]).groupby(g.values, observed=False).sum(); sh = sh / sh.sum() * 100
        med = float(np.median(dist[need])); res[key] = (sh, med)
        R(f"walk|{key}|median_m", int(round(med))); R(f"walk|{key}|within500_pct", round(sh.iloc[:2].sum(), 1))
        R(f"walk|{key}|over800_pct", round(sh.iloc[3:].sum(), 1))
    by = xx.groupby(["구군", "동"]).apply(lambda g: pd.Series({
        "의료_무환승정류장까지_중앙m": np.median(g.loc[g["의료_환승"] >= 1, "의료_무환승정류장까지m"]) if (g["의료_환승"] >= 1).any() else 0}))
    for d in ["화원읍", "옥포읍", "무태조야동", "혁신동", "안심1동", "진천동"]:
        v = by[by.index.get_level_values(1) == d]
        if len(v): R(f"walk_dong|{d}", int(round(v.iloc[0, 0])))
    log(f"[보행] 의료: 중앙값 {RESULT['walk|의료|median_m']}m, 500m 이내 {RESULT['walk|의료|within500_pct']}% / 일자리: 중앙값 {RESULT['walk|일자리|median_m']}m, 500m 이내 {RESULT['walk|일자리|within500_pct']}%")
    return res



# =============================================================================
# 9-2. 보고서용 배경 인포그래픽·분석 흐름도·종합 대시보드
#      (배경 수치는 참고문헌에 명시한 공식 통계·보도 사례이며 분석 결과가 아님)
# =============================================================================
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e6e5e1"
BLUE, ORANGE, AQUA, LIGHT = "#2a78d6", "#eb6834", "#1baf7a", "#cde2fb"
DPI = 500


def box(ax, x, y, w, h, fc, ec="none", r=0.02):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec, lw=1.2,
                                transform=ax.transAxes))


# ---------------------------------------------------------------- 배경 1: 정책·통계
def fig_policy_stats():
    fig = plt.figure(figsize=(12, 5.6))
    # (a) 수송부문 감축목표
    a = fig.add_axes([0.05, 0.2, 0.26, 0.62])
    vals = [9810, 6100]
    a.bar(["2018년 배출량", "2030년 목표"], vals, color=[INK2, BLUE], width=0.55)
    for i, v in enumerate(vals):
        a.text(i, v + 150, f"{v:,}만 톤", ha="center", fontsize=11, fontweight="bold", color=INK)
    a.annotate("", xy=(1, 6500), xytext=(0, 9950), arrowprops=dict(arrowstyle="->", color=ORANGE, lw=2))
    a.text(0.55, 8700, "−37.8%", color=ORANGE, fontsize=15, fontweight="bold")
    a.set_ylim(0, 11500); a.set_yticks([]); a.spines["left"].set_visible(False)
    a.set_title("(a) 국가 수송부문 온실가스 감축목표", loc="left", fontsize=12, fontweight="bold")
    fig.text(0.05, 0.08, "출처: 2050 탄소중립위원회, 2030 국가온실가스감축목표(NDC) 상향안(2021.10)\n"
             "      국토교통부, 국토교통 탄소중립 로드맵(2021.12)", fontsize=7.8, color=INK2)
    # (b) 수송부문 배출 구성
    b = fig.add_axes([0.38, 0.38, 0.27, 0.32])
    parts = [("승용차 약 60%", 60, ORANGE), ("기타 도로(버스·화물 등) 약 36%", 36, "#f6a679"), ("철도·해운·항공 4% 미만", 4, "#c9c8c2")]
    left = 0
    for lab, v, c in parts:
        b.barh([0], [v], left=left, color=c, height=0.5, edgecolor="white", linewidth=2)
        left += v
    b.text(30, 0, "승용차\n약 60%", ha="center", va="center", color="white", fontsize=11, fontweight="bold")
    b.text(78, 0, "버스·화물 등\n약 36%", ha="center", va="center", color=INK, fontsize=9.5)
    b.annotate("도로 96% 이상", xy=(48, 0.33), xytext=(48, 0.62), ha="center", fontsize=11, fontweight="bold", color=INK,
               arrowprops=dict(arrowstyle="-[, widthB=7.5, lengthB=0.6", color=INK2, lw=1.2))
    b.set_xlim(0, 100); b.set_ylim(-0.4, 0.85); b.axis("off")
    fig.text(0.38, 0.83, "(b) 수송부문 배출은 대부분 도로·승용차에서", fontsize=12, fontweight="bold")
    fig.text(0.38, 0.27, "수송부문 배출량 9,580만 톤(2022), 국가 배출의 약 14%\n→ 승용차 통행을 대중교통으로 바꾸는 것이\n   수송 탄소중립의 핵심 수단", fontsize=9.5, color=INK)
    fig.text(0.38, 0.08, "출처: 녹색교통운동 분석 인용 보도(M이코노미뉴스, 2025.6.20)\n      공모전 요강: 수송부문 배출의 약 97%가 도로교통", fontsize=7.8, color=INK2)
    # (c) 고령화
    c = fig.add_axes([0.71, 0.2, 0.27, 0.62]); c.axis("off")
    box(c, 0, 0.55, 1, 0.42, "#eef4fc")
    c.text(0.5, 0.86, "전국 65세 이상 인구", ha="center", fontsize=10.5, color=INK2, transform=c.transAxes)
    c.text(0.5, 0.67, "20.0%", ha="center", fontsize=30, fontweight="bold", color=BLUE, transform=c.transAxes)
    c.text(0.5, 0.595, "2024.12.23 초고령사회 진입 (1,024만 명)", ha="center", fontsize=8.8, color=INK, transform=c.transAxes)
    box(c, 0, 0.03, 1, 0.47, "#fdf0e6")
    c.text(0.5, 0.39, "대구 60세 이상 인구", ha="center", fontsize=10.5, color=INK2, transform=c.transAxes)
    c.text(0.5, 0.2, "31.37%", ha="center", fontsize=30, fontweight="bold", color=ORANGE, transform=c.transAxes)
    c.text(0.5, 0.09, "735,881명 · 군위군 63.3% (2026.9)", ha="center", fontsize=8.8, color=INK, transform=c.transAxes)
    fig.text(0.71, 0.86, "(c) 이동 약자가 빠르게 늘어남", fontsize=12, fontweight="bold")
    fig.text(0.71, 0.08, "출처: 행정안전부 주민등록 인구통계(2024.12, 뉴시스 보도)\n      행정안전부 연령별 인구현황(2026.9) — 본 분석 데이터", fontsize=7.8, color=INK2)
    fig.suptitle("배경 그림 1. 왜 지금 '대중교통 연결성'인가 — 정책 목표와 인구 변화", fontsize=14, fontweight="bold", x=0.02, ha="left", y=0.99)
    p = os.path.join(OUT_DIR, "bg1_policy_stats.png"); fig.savefig(p, dpi=DPI, bbox_inches="tight", facecolor="white"); plt.close(fig)
    log(f"  → 그림: {os.path.basename(p)}")


# ---------------------------------------------------------------- 배경 2: 국내 사례 타임라인
CASES = [
    ("2023.10", "대구 혁신도시 DRT 운행 개시", ["동구 혁신도시 의료R&D지구 68개 기업", "근로자 약 2,300명 출퇴근 대상", "AI가 다수 승객 경로를 실시간 최적화"],
     "서울신문, 2023.10.5", BLUE),
    ("2025.06", "대구 수요응답형 버스 시범사업", ["수성구 범물동·북구 연암서당골", "15인승 4대, 개소당 연 약 1.7억 원", "일 이용 60~80명 / 129명 수준"],
     "매일신문, 2026.1.26", BLUE),
    ("2025.07", "부산 산단 통근버스 노선 확대", ["13개 산단, 통근버스 47대", "하루 101회(출근 52·퇴근 49)", "주거지-산단 직결 부족 → 자가용 의존"],
     "뉴스서울, 2025.6.18", AQUA),
    ("2026.09", "달성군 지역맞춤형 교통 도입 용역", ["공공셔틀 8개 노선 9대", "DRT 4개 노선 6대(국가산단·심야 등)", "2027년 하반기 정식 운행 목표"],
     "경북매일, 2026.9.14", ORANGE),
]


def fig_cases():
    fig, ax = plt.subplots(figsize=(12, 5.4)); ax.axis("off")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.plot([0.04, 0.96], [0.78, 0.78], color=INK2, lw=2, zorder=1)
    w = 0.225
    for i, (d, ttl, pts, src, col) in enumerate(CASES):
        x = 0.03 + i * (w + 0.015)
        ax.scatter([x + w / 2], [0.78], s=180, color=col, zorder=3, edgecolor="white", lw=2)
        ax.text(x + w / 2, 0.86, d, ha="center", fontsize=13, fontweight="bold", color=col)
        box(ax, x, 0.24, w, 0.48, "#f6f6f4", ec=GRID)
        ax.text(x + 0.012, 0.66, ttl, fontsize=9.6, fontweight="bold", color=INK, va="top")
        for k, ptxt in enumerate(pts):
            ax.text(x + 0.012, 0.56 - k * 0.085, "• " + ptxt, fontsize=8.2, color=INK, va="top")
        ax.text(x + 0.012, 0.27, "출처: " + src, fontsize=7.6, color=INK2)
    box(ax, 0.03, 0.02, 0.94, 0.16, "#eef4fc")
    ax.text(0.05, 0.1, "시사점", fontsize=11, fontweight="bold", color=BLUE, va="center")
    ax.text(0.13, 0.1, "DRT·통근셔틀은 이미 도입·확대 중이나 대상지 선정은 민원·시범 위주이며, 대구 DRT는 지역에 따라 이용 편차가 큼\n"
            "→ '어디에 투입해야 가장 많은 사람이 환승 없이 목적지에 닿는가'를 데이터로 정하는 근거가 필요 (본 분석의 목적)",
            fontsize=9.6, color=INK, va="center")
    fig.suptitle("배경 그림 2. 국내 수요응답형 교통·산단 통근 정책 사례", fontsize=14, fontweight="bold", x=0.02, ha="left", y=0.98)
    p = os.path.join(OUT_DIR, "bg2_cases_timeline.png"); fig.savefig(p, dpi=DPI, bbox_inches="tight", facecolor="white"); plt.close(fig)
    log(f"  → 그림: {os.path.basename(p)}")


# ---------------------------------------------------------------- 방법: 분석 흐름도
def _flow_steps():
    _id = f"ID 결합 {RESULT['idjoin_rate']}%" if "idjoin_rate" in RESULT else "ID 결합률(코드 출력)"
    _rd = f"승차 결합 {RESULT['ride_join_rate']}%" if "ride_join_rate" in RESULT else "승차 결합률(코드 출력)"
    return [
        ("① 원본 9종", ["인구·정류소·배차", "노선정보·버스승차", "도시철도 승하차", "버스-철도 환승", "의료기관·산단"], "#eef4fc"),
        ("② 검증·결합", ["인코딩·결측·중복", "정류소ID 부여", "(이름+노선구성)", _id, _rd], "#eef4fc"),
        ("③ 잠재 연결성", ["노선=점, 도보환승=선", "BFS 최소 환승", "진행방향 검증", "반경 민감도", "(250·500·750m)"], "#fdf0e6"),
        ("④ 공급·수요", ["공표 배차간격", "평일 운행횟수", "출근시간 승차", "역별 환승 수요", "보행 대안거리"], "#fdf0e6"),
        ("⑤ AI·우선순위", ["RF(MDI)·교차검증", "K-Means 유형", "복합지표 순위", "가중치 민감도", "최대커버리지"], "#e8f6f0"),
        ("⑥ 정책·시나리오", ["셔틀 거점·순서", "의료 DRT 거점", "잠재 대상 vs 수혜", "탄소 순감축 범위", "검증표 자동 생성"], "#e8f6f0"),
    ]


def fig_flow():
    fig, ax = plt.subplots(figsize=(12.5, 3.9)); ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    STEPS = _flow_steps()
    n = len(STEPS); w = 0.142; gap = (1 - n * w) / (n - 1)
    for i, (ttl, items, fc) in enumerate(STEPS):
        x = i * (w + gap)
        box(ax, x, 0.05, w, 0.8, fc, ec=GRID)
        ax.text(x + w / 2, 0.76, ttl, ha="center", fontsize=11.5, fontweight="bold", color=INK)
        for k, it in enumerate(items):
            ax.text(x + w / 2, 0.6 - k * 0.11, it, ha="center", fontsize=8.8, color=INK)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.003, 0.45), (x + w + gap - 0.003, 0.45), arrowstyle="-|>",
                                         mutation_scale=16, color=INK2, lw=1.5, transform=ax.transAxes))
    ax.text(0.0, 0.94, "원본 CSV·ZIP 9종 → 파이썬 코드 1개 실행 → 모든 표·그림·검증표 자동 생성 (결과값 직접 입력 없음)", fontsize=9.5, color=INK2)
    fig.suptitle("그림 M. 분석 흐름도", fontsize=13.5, fontweight="bold", x=0.01, ha="left", y=1.02)
    p = os.path.join(OUT_DIR, "method_flow.png"); fig.savefig(p, dpi=DPI, bbox_inches="tight", facecolor="white"); plt.close(fig)
    log(f"  → 그림: {os.path.basename(p)}")


def fig_network_concept():
    """처음 보는 사람을 위한 '환승 횟수 계산' 개념도."""
    fig, ax = plt.subplots(figsize=(12, 3.6)); ax.axis("off"); ax.set_xlim(0, 12); ax.set_ylim(0, 3.6)
    # 정류소 A(집) - 노선1 - 환승 정류소 - 노선2 - 병원
    ax.plot([0.8, 4.6], [1.8, 1.8], color=BLUE, lw=5, solid_capstyle="round")
    ax.plot([5.4, 9.4], [1.8, 1.8], color=ORANGE, lw=5, solid_capstyle="round")
    ax.plot([0.8, 9.4], [0.55, 0.55], color=AQUA, lw=5, ls=(0, (2, 1.2)), solid_capstyle="round")
    for xx, lab in [(0.8, "집 앞 정류소"), (4.6, "정류소 X"), (5.4, "정류소 Y"), (9.4, "병원 앞 정류소")]:
        ax.scatter([xx], [1.8], s=260, color="white", edgecolor=INK, lw=2, zorder=3)
        ax.text(xx, 2.25, lab, ha="center", fontsize=10, color=INK)
    ax.annotate("", xy=(5.35, 1.55), xytext=(4.65, 1.55), arrowprops=dict(arrowstyle="<->", color=INK2, lw=1.3))
    ax.text(5.0, 1.15, "150m\n(200m 이내 → 환승 가능)", ha="center", fontsize=8.8, color=INK2)
    ax.text(2.7, 2.0, "노선 1", color=BLUE, fontsize=10, fontweight="bold", ha="center")
    ax.text(7.4, 2.0, "노선 2", color=ORANGE, fontsize=10, fontweight="bold", ha="center")
    ax.text(5.1, 0.72, "노선 3 (두 정류소를 모두 지나면 '환승 없음')", color=AQUA, fontsize=10, fontweight="bold", ha="center")
    ax.text(10.1, 2.15, "노선 1 → 노선 2", fontsize=10.5, fontweight="bold", color=INK)
    ax.text(10.1, 1.75, "= 환승 1회", fontsize=10.5, color=ORANGE, fontweight="bold")
    ax.text(10.1, 0.75, "노선 3 = 환승 0회", fontsize=10.5, color=AQUA, fontweight="bold")
    ax.text(0.0, 3.3, "노선을 '점', 걸어서 갈아탈 수 있는 관계를 '선'으로 보고, 출발 정류소의 노선에서 목적지 노선까지 몇 번 건너야 하는지를 셈",
            fontsize=10, color=INK)
    fig.suptitle("그림 N. 최소 환승 횟수 계산 방식 (개념도)", fontsize=13, fontweight="bold", x=0.01, ha="left", y=1.04)
    p = os.path.join(OUT_DIR, "method_transfer_concept.png"); fig.savefig(p, dpi=DPI, bbox_inches="tight", facecolor="white"); plt.close(fig)
    log(f"  → 그림: {os.path.basename(p)}")

def fig_dashboard():
    names = ["fig3_heatmap.png", "fig1_supply_headway.png", "fig6_rf_mdi.png", "fig8_policy.png"]
    fig, axs = plt.subplots(2, 2, figsize=(20, 12.5))
    for a, n in zip(axs.flat, names):
        a.imshow(plt.imread(os.path.join(OUT_DIR, n))); a.axis("off")
    fig.suptitle("대구시 의료·일자리 대중교통 연결성 격차 분석 요약 (V5)", fontsize=20, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.97]); fig.savefig(os.path.join(OUT_DIR, "fig0_dashboard_v5.png"), dpi=300, facecolor="white")
    plt.close(fig); log("  → 그림: fig0_dashboard_v5.png")


# =============================================================================
# 10. 실행
# =============================================================================
def main():
    setup_font()
    log("=" * 72); log(f"V5 분석 시작 | 원본: {DATA_DIR} | 출력: {OUT_DIR}"); log("=" * 72)
    pop, gu = load_population()
    bs = load_stops()
    hw, wk = load_headway()
    ri = load_route_info()
    st, alight = load_subway(bs)
    transfer = load_transfer(st)
    ride = load_bus_ridership()
    med, ind = load_destinations_raw()
    if ri is not None:   # 노선 목록 정합성: 위치정보·배차·노선정보 노선번호 비교
        a, b, c = {r for rs in bs["routes"] for r in rs}, set(wk["노선"]), set(ri["노선번호"].astype(str))
        R("routes_in_all3", len(a & b & c)); R("routes_loc_only", len(a - b))
        log(f"[노선 정합성] 3개 자료 공통 노선 {len(a & b & c)}개, 위치정보에만 있는 노선 {len(a - b)}개(배차자료 없음)")
    bs = assign_stop_ids(bs, wk, ride)
    bs = stop_supply(bs, wk)

    # ---- 연결성(기준) + 방향 검증 ----
    conn, info = connectivity(bs, st, med, ind, CFG["walk_transfer_m"], CFG["walk_dest_m"], check_direction=True)
    dd = info["dd"]; R("net_routes", info["n_routes"]); R("net_edges", info["n_edges"])
    R("dest_firms_covered", int(dd.loc[dd.type == "일자리", "weight"].sum()))
    R("dest_firms_pct", round(RESULT["dest_firms_covered"] / RESULT["n_firms"] * 100, 1))
    m, x = dong_table(bs, conn, pop, ride, transfer, info["st_ok"])
    e = exposure_summary(m)
    R("exp_old", int(round(e["old"]))); R("exp_old_pct", round(e["old_pct"], 1)); R("exp_young", int(round(e["young"]))); R("exp_young_pct", round(e["young_pct"], 1))
    R("stop_med_need_pct", round((conn["의료_환승"] >= 1).mean() * 100, 1)); R("stop_job_need_pct", round((conn["성서_환승"] >= 1).mean() * 100, 1))
    xx = x.merge(pop, on=["구군", "동"], how="left"); nn = xx.groupby(["구군", "동"])["정류소명"].transform("size")
    R("exp_2plus_old_pct", round(((xx["의료_환승"] >= 2) * xx["고령60"] / nn).sum() / m["고령60"].sum() * 100, 1))
    R("exp_2plus_young_pct", round(((xx["성서_환승"] >= 2) * xx["청년2039"] / nn).sum() / m["청년2039"].sum() * 100, 1))
    gx = m.groupby("구군").agg(o=("의료_잠재노출인구", "sum"), O=("고령60", "sum"), y=("성서_잠재노출인구", "sum"), Y=("청년2039", "sum"))
    for k, r in gx.iterrows():
        R(f"gu_exp_old_pct|{k}", round(r["o"] / r["O"] * 100, 1)); R(f"gu_exp_young_pct|{k}", round(r["y"] / r["Y"] * 100, 1))
    log(f"[연결성·잠재] 60세+ {RESULT['exp_old']:,}명({RESULT['exp_old_pct']}%), 20~39세 {RESULT['exp_young']:,}명({RESULT['exp_young_pct']}%) 환승 필요(추정)")

    # ---- 민감도 ----
    rows = []
    for dm in CFG["sens_dest_m"]:
        c2, _ = connectivity(bs, st, med, ind, CFG["walk_transfer_m"], dm); m2, _ = dong_table(bs, c2, pop, ride, None, None)
        e2 = exposure_summary(m2); rows.append(dict(변경="목적지반경", 값=dm, 의료_노출비율=round(e2["old_pct"], 1), 성서_노출비율=round(e2["young_pct"], 1)))
    for tm in CFG["sens_transfer_m"]:
        c2, _ = connectivity(bs, st, med, ind, tm, CFG["walk_dest_m"]); m2, _ = dong_table(bs, c2, pop, ride, None, None)
        e2 = exposure_summary(m2)
        x2 = c2.join(bs[["정류소명"]]).merge(pop, on=["구군", "동"], how="left"); n2 = x2.groupby(["구군", "동"])["정류소명"].transform("size")
        o2 = ((x2["의료_환승"] >= 2) * x2["고령60"] / n2).sum() / m2["고령60"].sum() * 100
        y2 = ((x2["성서_환승"] >= 2) * x2["청년2039"] / n2).sum() / m2["청년2039"].sum() * 100
        rows.append(dict(변경="환승반경", 값=tm, 의료_노출비율=round(e2["old_pct"], 1), 성서_노출비율=round(e2["young_pct"], 1),
                         의료_2회이상=round(o2, 2), 성서_2회이상=round(y2, 2)))
    sens = pd.DataFrame(rows); sens.to_csv(os.path.join(OUT_DIR, "sensitivity_radius.csv"), index=False, encoding="utf-8-sig")
    for r in sens.itertuples():
        R(f"sens|{r.변경}|{r.값}|old", r.의료_노출비율); R(f"sens|{r.변경}|{r.값}|young", r.성서_노출비율)
        if r.변경 == "환승반경":
            R(f"sens2|{r.값}|old", r.의료_2회이상); R(f"sens2|{r.값}|young", r.성서_2회이상)
    log("[민감도]\n" + sens.to_string(index=False))

    # ---- 우선순위 ----
    mprio, psens = priority(m)
    psens.to_csv(os.path.join(OUT_DIR, "priority_weight_sensitivity.csv"), index=False, encoding="utf-8-sig")
    for target, expcol in [("의료", "의료_잠재노출인구"), ("일자리", "성서_잠재노출인구")]:
        mprio[f"{target}_V4순위"] = mprio[expcol].rank(ascending=False, method="min").astype(int)
        cmp = mprio.sort_values(f"{target}_우선순위")[["구군", "동", f"{target}_V4순위", f"{target}_우선순위"]].rename(columns={f"{target}_V4순위": "V4", f"{target}_우선순위": "V5"})
        fig_rank_compare(cmp, target)
        R(f"rank_rho|{target}", round(mprio[f"{target}_V4순위"].corr(mprio[f"{target}_우선순위"], method="spearman"), 3))
        R(f"rank_top10_overlap|{target}", len(set(cmp.head(10)["동"]) & set(mprio.nsmallest(10, f"{target}_V4순위")["동"])))
        top = mprio.sort_values(f"{target}_우선순위").head(10)
        for i, r in enumerate(top.itertuples(), 1):
            R(f"top|{target}|{i}", f"{r.구군} {r.동}")
        log(f"[V4↔V5 {target}] 순위상관 {RESULT[f'rank_rho|{target}']}, 상위10 일치 {RESULT[f'rank_top10_overlap|{target}']}개")
    cols = ["구군", "동", "고령60", "청년2039", "의료_환승필요비율", "성서_환승필요비율", "평균경유노선수", "배차_중앙", "운행_중앙",
            "장배차비율", "배차결측비율", "출근승차_천명당", "인근역_환승월평균", "의료_잠재노출인구", "성서_잠재노출인구",
            "의료_V4순위", "의료_우선순위", "일자리_V4순위", "일자리_우선순위"]
    hot_med = mprio.sort_values("의료_우선순위").head(10)[cols]; hot_job = mprio.sort_values("일자리_우선순위").head(10)[cols]
    hot_med.to_csv(os.path.join(OUT_DIR, "priority_medical_top10.csv"), index=False, encoding="utf-8-sig")
    hot_job.to_csv(os.path.join(OUT_DIR, "priority_job_top10.csv"), index=False, encoding="utf-8-sig")
    log("[V5 의료 우선 상위10]\n" + hot_med.round(1).to_string(index=False))
    log("[V5 일자리 우선 상위10]\n" + hot_job.round(1).to_string(index=False))

    # ---- 그림 ----
    log("\n[그림]")
    fig_supply(bs); fig_exposure(x, pop); fig_heatmap(x, pop, dd); fig_sensitivity(sens)
    walk = walk_alt(x, pop); fig_walk(walk)
    run_rf(x, pop)
    clusters, prof = run_kmeans(mprio)
    sh = run_shuttle(x, pop, dd, mprio); drt = run_drt(x, pop, mprio); fig_policy(x, dd, sh, drt)
    carbon(sh)

    # ---- 결과 저장 ----
    mprio.merge(clusters, on=["구군", "동"], how="left").to_csv(os.path.join(OUT_DIR, "dong_indicators_v5.csv"), index=False, encoding="utf-8-sig")
    x.drop(columns=["routes", "노선방향"]).to_csv(os.path.join(OUT_DIR, "stop_indicators_v5.csv"), index=False, encoding="utf-8-sig")
    pd.DataFrame(VALID).to_csv(os.path.join(OUT_DIR, "data_validation.csv"), index=False, encoding="utf-8-sig")
    if "direction" in info: info["direction"].to_csv(os.path.join(OUT_DIR, "bfs_direction_check.csv"), index=False, encoding="utf-8-sig")
    json.dump({"CFG": {k: (list(v) if isinstance(v, range) else v) for k, v in CFG.items()}, "ASSUMPTIONS": ASSUMPTIONS},
              open(os.path.join(OUT_DIR, "settings_and_assumptions.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump({k: (v if isinstance(v, (int, float, str, bool)) or v is None else str(v)) for k, v in RESULT.items()},
              open(os.path.join(OUT_DIR, "report_values.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    log("\n[보고서용 인포그래픽]")
    fig_policy_stats(); fig_cases(); fig_flow(); fig_network_concept(); fig_dashboard()
    log("\n[데이터 검증표]\n" + pd.DataFrame(VALID).to_string(index=False))
    open(os.path.join(OUT_DIR, "analysis_log_v5.txt"), "w", encoding="utf-8").write("\n".join(LOG))
    print(f"\n완료: 모든 결과가 {OUT_DIR} 에 저장되었습니다. (표·그래프 {len(os.listdir(OUT_DIR))}개)")


if __name__ == "__main__":
    main()
