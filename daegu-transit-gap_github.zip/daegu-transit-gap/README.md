# 갈아타야 닿는 병원과 일자리
### AI 기반 대구시 의료·일자리 대중교통 연결성 격차 진단과 녹색교통 전환 전략

「AI와 함께하는 교통문제 해결을 위한 데이터 분석 공모전」 분석 코드입니다.
`data/`의 원본 공공데이터 9종을 직접 읽어 **보고서의 모든 수치·그래프를 처음부터 다시 계산**합니다.
분석 결과값을 코드에 직접 입력한 부분은 없으며, 정책 시나리오 가정값은 `daegu_transit_gap_v5.py` 상단 `ASSUMPTIONS`에 분리되어 있습니다.

## 1. 빠른 실행

### Google Colab (권장)
`run_in_colab.ipynb`를 Colab에서 열어 위에서부터 실행하거나, 새 노트북에서:
```python
!git clone https://github.com/<계정>/daegu-transit-gap.git
%cd daegu-transit-gap
!apt-get -qq install -y fonts-nanum > /dev/null
!pip install -q -r requirements.txt
!python daegu_transit_gap_v5.py
```
※ 한글 폰트를 처음 설치한 경우, 그래프 한글이 깨지면 **런타임 → 세션 다시 시작** 후 마지막 줄만 다시 실행하세요.

### 로컬 PC
```bash
pip install -r requirements.txt
python daegu_transit_gap_v5.py
```
VS Code·PyCharm 등에서는 `daegu_transit_gap_v5.py`를 열고 **실행 버튼만 누르면** 됩니다.
(같은 폴더의 `data/`를 자동으로 읽고 `outputs_v5/`에 모든 결과를 저장)
- 환경: Python 3.9 이상, 실행 시간 약 1~2분
- Windows는 맑은 고딕을 자동 사용합니다.

## 2. 파일 구성
```
daegu-transit-gap/
├─ daegu_transit_gap_v5.py   # 단일 실행 파일: 전처리·결합 검증·BFS·배차·우선순위·RF·K-Means·
│                            #   최대커버리지·탄소 시나리오·배경 인포그래픽·종합 대시보드까지 전부
├─ run_in_colab.ipynb        # Colab 실행용 노트북
├─ requirements.txt
└─ data/                     # 원본 공공데이터 9종 (아래 출처 참조)
```

## 3. 분석 단계
1. **원본 검증**: 인코딩(UTF-8/CP949) 자동 판별, 파일별 행수·고유키 중복·결측률 → `data_validation.csv`
2. **자료 결합**: 위치정보(정류소ID 없음)에 배차자료의 정류소ID 부여(이름 유일 → 이름, 동명 → 경유노선 구성 유사도), 결합률 출력
3. **노선망 기반 잠재 환승 연결성**: 노선=노드, 200m 도보환승=간선 그래프에서 BFS로 상급종합병원·산업단지까지 최소 환승 횟수, 진행방향 검증, 반경 민감도(250·500·750m)
4. **공급·수요**: 정류소별 최단 공표 배차간격·평일 운행횟수, 출근시간 승차, 버스-철도 환승 수요, 보행 대안거리
5. **AI**: RandomForest(학습/검증 분리, 5-Fold CV, `feature_importances_` 기반 MDI), K-Means(실루엣), 복합지표 우선순위·가중치 민감도, 최대커버리지(셔틀 거점), 가중 K-Means(의료 DRT 거점)
6. **시나리오**: 승용차 회피배출 − 전기셔틀 배출(전환율 5·10·15%, 배출계수 범위)

## 4. 주요 출력 (`outputs_v5/`)
| 파일 | 내용 |
|---|---|
| `report_values.json` | 보고서에 쓰인 모든 수치 |
| `analysis_log_v5.txt` | 단계별 실행 로그 |
| `data_validation.csv` | 파일별 행수·고유키 중복·결측률·기간 |
| `headway_coverage_by_gu.csv` | 구·군별 배차자료 결합 정류소 수·결합률 |
| `bfs_direction_check.csv` | 무환승 판정의 진행방향 검증 |
| `sensitivity_radius.csv`, `sensitivity_shuttle.csv`, `priority_weight_sensitivity.csv` | 민감도 분석 |
| `dong_indicators_v5.csv`, `stop_indicators_v5.csv` | 행정동·정류소별 지표 |
| `priority_medical_top10.csv`, `priority_job_top10.csv` | 취약지역 우선순위 |
| `rf_feature_importance_mdi.csv`, `kmeans_profile.csv` | AI 결과 |
| `sim_shuttle_hubs.csv`, `sim_drt_hubs.csv`, `carbon_scenarios.csv` | 정책 시뮬레이션 |
| `settings_and_assumptions.json` | 분석 설정값·정책 가정값 |
| `fig*.png` (+ `_a`, `_b` 패널) | 분석 그래프 500dpi |
| `bg1_*`, `bg2_*`, `method_*`, `fig0_dashboard_v5.png` | 배경 인포그래픽·분석 흐름도·종합 대시보드 |

## 5. 데이터 출처
| 데이터 | 제공기관 | URL |
|---|---|---|
| 시내버스 정류소 위치정보 (2026.09.02.) | 대구광역시 | https://www.data.go.kr/data/15050946/fileData.do |
| 시내버스 정류소별_노선별_평균배차간격 (2025.11.14.) | 대구광역시 | https://www.data.go.kr/data/15060936/fileData.do |
| 시내버스 노선정보 (2025.12.02.) | 대구광역시 | https://www.data.go.kr/data/15156114/fileData.do |
| 정류소별 시간대별 승하차인원 (2024.01.~2025.12.) | 대구광역시 | https://www.data.go.kr/data/15050942/fileData.do |
| 역별일별시간별승하차인원현황 (2026.01.~08.) | 대구교통공사 | https://www.data.go.kr/data/15002503/fileData.do |
| 도시철도 버스 간 역별 환승수송현황 (2023.01.~2026.08.) | 대구교통공사 | https://www.data.go.kr/data/15133893/fileData.do |
| 의료기관 현황 (2026.01.01.) | 대구광역시 | https://www.data.go.kr/data/3033586/fileData.do |
| 산업단지 기업 등록현황 (2026.08.25.) | 대구광역시 | https://www.data.go.kr/data/15073542/fileData.do |
| 연령별 인구현황 월간 (2026.09.) | 행정안전부 | https://jumin.mois.go.kr/ |

새 버전의 원본 파일로 바꿔도 파일명 일부만 맞으면 자동 인식합니다.

## 6. 해석 시 유의사항
- 환승 횟수는 정류소 통과 순서 자료가 없어 **노선망 기반 잠재 환승 연결성**이며, 실제 최소 환승 횟수가 아닙니다.
- 노출인구·서비스 대상인구는 행정동 인구를 정류소에 균등 배분한 **잠재 추정치**입니다.
- 공표 평균배차간격은 운영계획상 값이며 **실제 대기시간이 아닙니다**.
- 탄소감축량은 전환율·배출계수 등 **가정에 따른 시나리오**입니다.
- 랜덤포레스트 변수 중요도(MDI)는 예측 기여도이며 인과효과가 아닙니다.
